EXTENSION QEM ACOTADA PARA EL PAPER SSF - VERSION 2
Fecha: 9 de noviembre de 2026
Base: manuscrito «Exact canonical recomposition and silent-failure
estimation for small-set-flip decoding», borrador fechado 7 de noviembre
de 2026, suministrado con nombre de archivo del 8 de noviembre.

OBJETIVO Y ESTADO

Esta carpeta contiene una extensión matemática desarrollada y dos ejemplos
finitos reproducibles: el circuito original de cinco datos y el PATH25
conectado del manuscrito. V2 añade también un rango certificado de
expectativas ideales para las que mejora el MSE. La aportación propuesta
es una consecuencia operacional
de los caracteres del paper: estimación certificada de observables Z
codificados después del SSF especificado. La inversión escalar del ruido y
QEM lógico son ideas conocidas; no se afirma prioridad bibliográfica ni una
ventaja general frente a otros protocolos.

CONTENIDO

SSF_QEM_extension_v2.pdf  Nota técnica completa en inglés, con propuesta de
                        subsección, pruebas, fórmulas, ejemplos y ubicación.
manuscript_insert.tex   Subsección propuesta para el final de la sección 5.
proof_details.tex       Hipótesis, atenuación, filtro, intervalos y costes.
finite_example.tex      Ejemplo del circuito original del apéndice G.
mse_details.tex         MSE exacto, punto de cruce y certificado de mejora.
mse_range.tex           Rango de expectativas con mejora uniforme certificada.
path25_example.tex      PATH25 conectado, corrección no lineal y certificado.
positioning.tex        Posicionamiento y cambios mínimos de integración.
qem_extension.tex      Documento principal que reúne el desarrollo.
qem_references.bib     Tres referencias primarias verificadas sobre QEM.
code/                  Productores reproducibles en Python.
results/               Circuito de cinco datos y rangos certificados de MSE.
results/path25/        Referencias y certificados racionales de PATH25.
figures/               Figura de MSE en PNG y SVG.
manifest.sha256        Huellas de los archivos incluidos, excepto sí mismo.

REPRODUCCION

Python 3.10 o posterior. La aritmética y la verificación usan únicamente la
biblioteca estándar. Desde esta carpeta:

    python reproduce.py

Para regenerar además la figura se necesitan numpy y matplotlib:

    python reproduce.py --plots

Pasos individuales:

    python code/exact_qem_fixture.py --out results
    python code/finite_observable_certificate.py --e 1/20 --cutoff 2
    python code/certified_mse_ranges.py
    python code/path25_exact_qem.py --out results/path25
    python code/path25_exact_qem.py --certificate-only --cutoff 2 --out results/path25
    python code/analyze_qem.py --plots

En el circuito de cinco datos, el productor parcial genera y propaga
solamente 275 historias. No consulta la enumeración completa ni sus
resultados para construir el certificado. La referencia exhaustiva de
2048 historias sirve para contrastarlo por separado.

certified_mse_ranges.py usa únicamente results/partial_certificate.json:
no lee el coeficiente exacto ni la enumeración completa. Produce
results/certified_mse_ranges.json y results/certified_mse_ranges.csv.

En PATH25, el modo completo prepara los 4096 síndromes, calcula referencias
racionales por Walsh y genera el catálogo de peso hasta tres (8474
historias). El modo --certificate-only --cutoff 2 prepara los mismos 4096
síndromes y genera sólo 704 historias de fuentes; no genera las de mayor
peso, no ejecuta Walsh y no lee probabilidades exactas de referencia.
Por tanto, su coste declarado es la preparación de 4096 decodificaciones
más el tratamiento de 704 historias, y no solamente las 704 historias.
Ambos modos escriben en results/path25 con los comandos anteriores.

reproduce.py ejecuta los productores y contrasta los certificados parciales
con las referencias mediante fracciones exactas. Para omitir las figuras
en un paso individual, se puede ejecutar analyze_qem.py sin --plots.

Para compilar el PDF con una distribución LaTeX completa:

    latexmk -pdf -interaction=nonstopmode -halt-on-error qem_extension.tex

Las tablas .tex se generan directamente a partir de las fracciones exactas.
El código adicional para figuras no altera los certificados racionales.
Las salidas publicadas en esta carpeta fueron ejecutadas con éxito.

EJEMPLO 1: CIRCUITO ORIGINAL DE CINCO DATOS

Se reproduce el circuito original de 5 datos, 11 candidatos SSF, 4
localizaciones ruidosas categóricas y 2048 asignaciones. La comparación con
el punto del manuscrito da Psil = 9.976554017523... x 10^-42.

Para e=1/20, el representante u=5 (Z0 Z2) tiene lambda=6958/9375.
El certificado con como máximo 2 localizaciones no basales da:

    L = 0.741308569444...
    U = 0.742947944444...
    c = (L+U)/2 = 0.742128256944...
    r = (U-L)/(U+L) = 0.001104509217...

37 531 ejecuciones independientes sin filtrado son suficientes para error
aditivo <=0.02 con probabilidad >=0.95, para cualquier estado codificado
del ejemplo, bajo el modelo declarado y lectura final ideal.

Para el estado codificado con expectativa ideal mu=3/5, a 1000 ejecuciones:

    Representante   MSE sin mitigar    MSE con calibración    Cociente
    u=5             0.02473007457      0.00145563708          16.989
    u=10            0.00228640000      0.00078801968           2.901

Son momentos calculados exactamente, no resultados de Monte Carlo.
Las igualdades de MSE corresponden al estimador lineal sin recorte;
recortarlo a [-1,1] sólo puede reducir su error cuadrático.
Cada fila compara el mismo representante antes y después de mitigar.
La calibración de la tabla procede del intervalo certificado. El coste
clásico de calibración se informa por separado.

RANGOS DE EXPECTATIVAS CON MEJORA CERTIFICADA

Para el mismo circuito, e=1/20, cutoff 2 y M=1000, los intervalos de 275
historias permiten certificar la mejora para todos los coeficientes que
contienen y para los siguientes rangos cerrados:

    u=5:     0.111 <= |mu| <= 1
    u=10:    0.183 <= |mu| <= 1

Los umbrales estrictos calculados antes de redondear son aproximadamente
0.1107315 y 0.1820112. La condición necesaria y suficiente corresponde
al estimador lineal; para el estimador recortado sigue siendo suficiente.
Esta caracterización no aprende mu ni propone una selección adaptativa
a partir de las mediciones. La mejora no es uniforme sobre todos los
estados: con mu=0 se pierde por varianza. Tampoco un rango más amplio
implica que un representante tenga menor MSE absoluto que otro.

EJEMPLO 2: PATH25 CONECTADO Y CORRECCION NO LINEAL

Se reconstruye PATH25 del apéndice F a partir de la semilla (3,6,12), con
25 datos, 12 checks independientes de cada tipo y un qubit lógico. Se
conservan sus 103 candidatos generales, beta=1/2, el denominador |HX F|
del score y los desempates ascendentes (|F|, mask(F)). No se impone el
filtro FGL regular a esta semilla no regular.

El host de ejecución es conectado. De los 4096 síndromes, 4005 requieren
al menos dos acciones aceptadas y las trazas alcanzan ocho acciones.
Estas son cuentas combinatorias, no probabilidades bajo el ruido.

El representante u0=4369 se conserva como control cerrado. El ejemplo
principal usa u*=135447, protegido y lógicamente equivalente, cuyo signo
de corrección no es afín: difiere del único candidato lineal en 1280
síndromes. Los caracteres sin filtro dependen del representante físico.

Con p=1/50, q=1/100 y el representante u*, la referencia exacta da:

    lambda = 0.807673260221...
    P0     = 0.844529770141...
    lambda_T = 0.988984030445...

El certificado de peso total hasta dos (704 historias) produce:

    L = 0.779793577846...
    U = 0.827464298809...
    c = (L+U)/2 = 0.803628938328...

Para el estado codificado con mu=3/5 y M=1000 ejecuciones sin filtro:

    MSE sin mitigar = 0.014081405946...
    MSE con c      = 0.001193905410...

El cociente de estos momentos exactos es 11.7944... . Además, sin conocer
lambda, el intervalo por sí solo da:

    peor MSE con c       < 0.001526148938
    mejor MSE sin mitigar > 0.011470193567

La razón de las cotas exactas supera 7.5: el certificado garantiza una
reducción por un factor mayor que 7.5 para ese estado y ese presupuesto.
Recortar a [-1,1] preserva esta garantía. El coste clásico 4096+704 está
separado de las 1000 ejecuciones cuánticas.

El catálogo de peso hasta tres contiene 8474 historias y estrecha el
intervalo a [0.804124772196..., 0.810760663234...] en este punto.
Incluye 3768 historias con varios componentes de ejecución; 3131 tienen
al menos dos trazas locales activas. Se verifican la restricción y la
recomposición canónica. Son nuevos conteos del catálogo completo de
peso bajo, distintos de la selección de 565 fuentes del manuscrito.

El ruido p,q positivo de PATH25 es una extensión fenomenológica explícita
del caso q=0 publicado, con el mismo código y decodificador. No es una
simulación de ruido a nivel de circuito. La referencia Walsh tiene coste
O(h 2^h) en operaciones aritméticas, con h=12, además de preparar el
decodificador: no demuestra escalabilidad polinomial ni implementa KP.

ALCANCE QUE SE DEBE CONSERVAR AL INTEGRAR

1. El input es un estado codificado y el ruido tratado es el bloque fijado.
2. El resultado sin filtro depende del representante físico concreto.
3. La lectura final ideal de todos los datos hace observable el filtro
   físico; el síndrome ruidoso del decodificador no lo sustituye.
4. Ruido adicional de lectura, incertidumbre en las tasas y desajustes del
   modelo requieren tratamiento explícito.
5. El acceso clásico sin filtro usa sus propias hipótesis del Corolario 10.
   El rectángulo certificado sólo para particiones filtradas no se transfiere.
6. La identidad del circuito es exacta; la enumeración finita no demuestra
   un algoritmo polinomial sin filtro en el rectángulo de ruido del circuito.
7. No hace falta un testigo de fallo raro para un carácter a precisión
   relativa; el coste de medición lambda^-2 y la aceptación P0^-1 subsisten.
8. El circuito de cinco datos ejecuta como máximo una acción SSF. PATH25
   añade un host conectado, trazas de hasta ocho acciones y recomposición
   con varios componentes. Ambos son ejemplos finitos; no establecen
   escalabilidad en familias crecientes.
9. La precisión fija del coeficiente deja un piso de sesgo. Para resolver
   sesgos residuales muy pequeños puede ser necesaria mucha más precisión.
10. El texto está preparado para integración en el manuscrito; los números
    del documento base deben sustituirse por sus etiquetas LaTeX reales.

DATOS AUXILIARES

exact_metrics.csv incluye por separado una ilustración fenomenológica
Bernoulli con el mismo código. Está identificada por su campo model y no
se usa en lugar del circuito original.

La columna de varianza filtrada por ejecuciones totales corresponde al
estimador mean(1_T*Y)/(P0*lambda_T), con los normalizadores exactos conocidos.
Es distinto de recoger un número fijo de muestras aceptadas, cuyo coste
total es aleatorio y tiene esperanza m/P0.

Las cotas de confianza son suficientes y conservadoras. Las tasas e=0.01,
0.03,0.05,0.10 se certifican aquí como instancias finitas; no se presentan
como una ampliación de la región uniforme del teorema de particiones.
Lo mismo se aplica a los puntos fenomenológicos de PATH25:
(p,q)=(0.01,0.005), (0.02,0.01) y (0.03,0.01).
