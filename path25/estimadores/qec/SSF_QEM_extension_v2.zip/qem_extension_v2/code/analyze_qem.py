#!/usr/bin/env python3
"""Exact MSE comparison and finite error certificate for the QEM extension.

Run after exact_qem_fixture.py; the arithmetic uses only Python's standard
library. Add --plots to create PNG/SVG figures (requires matplotlib/numpy).
All tabular values are rational; decimals are presentation values. The
Hoeffding sample budget uses a rational upper bound on log(40), verified by
a lower Taylor bound on exp(369/100). No Monte Carlo is used.
"""
from __future__ import annotations

import argparse
import csv
import json
from decimal import Decimal, localcontext
from fractions import Fraction as F
from math import factorial
from pathlib import Path


def dec(x, digits=18):
    with localcontext() as ctx:
        ctx.prec = digits
        return str(Decimal(x.numerator)/Decimal(x.denominator))


def ceiling(x):
    return -(-x.numerator // x.denominator)


def raw_mse(lam, mu, m):
    return (1-lam*lam*mu*mu)/m + (1-lam)**2*mu*mu


def calibrated_mse(lam, mu, m, c):
    return (1-lam*lam*mu*mu)/(m*c*c) + (lam/c-1)**2*mu*mu


def crossing(lam, mu):
    return (1-lam*lam*mu*mu)*(1+lam)/(lam*lam*(1-lam)*mu*mu)


def difference(lam, mu, m, c):
    a=1/(c*c)-1
    expanded=a/m+mu*mu*(a*(1-F(1,m))*lam*lam+2*(1-1/c)*lam)
    direct=calibrated_mse(lam,mu,m,c)-raw_mse(lam,mu,m)
    assert expanded == direct
    return expanded


def csv_write(path, rows):
    with path.open('w',newline='',encoding='utf-8') as stream:
        w=csv.DictWriter(stream,fieldnames=list(rows[0]))
        w.writeheader();w.writerows(rows)


def exact_fields(row, **values):
    for key,value in values.items():
        row[key]=str(value)
        row[key+'_decimal']=dec(value)
    return row


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    parser.add_argument('--plots',action='store_true')
    args=parser.parse_args()
    root=args.root.resolve();results=root/'results'
    source=json.loads((results/'exact_results.json').read_text())
    with (results/'finite_calibration.csv').open() as stream:
        calibration=list(csv.DictReader(stream))
    get_cal=lambda e,u,k:next(row for row in calibration
        if row['e']==str(e) and int(row['u_mask'])==u
        and int(row['cutoff_nonbaseline_locations'])==k)
    evals={F(row['e']):row for row in source['circuit_evaluations']}
    mu=F(3,5);epsilon=F(1,50);delta=F(1,20);log_upper=F(369,100)
    exp_lower=sum(log_upper**j/F(factorial(j)) for j in range(20))
    assert exp_lower>40  # proves log(2/delta)=log(40)<369/100
    budgets=(1,10,30,100,1000,10000,1000000)
    mse_rows=[];cert_rows=[];resource_rows=[]
    for e,ev in evals.items():
        if ev['published_checksum_point']:continue
        p0=F(ev['P0']);lam_t=F(ev['lambda_T']['5'])
        resource_rows.append(exact_fields({'e':str(e)},P0=p0,lambda_T=lam_t,
            unfiltered_cost_u5=1/F(ev['lambda']['5'])**2,
            unfiltered_cost_u10=1/F(ev['lambda']['10'])**2,
            filtered_expected_cost=1/(p0*lam_t**2)))
        for u in (5,10):
            lam=F(ev['lambda'][str(u)])
            for k in (1,2,3,4):
                cal=get_cal(e,u,k)
                low,high,c=(F(cal[key]) for key in
                    ('lambda_lower','lambda_upper','lambda_midpoint'))
                assert 0<low<=lam<=high<=1
                radius=(high-low)/(high+low)
                assert abs(lam/c-1)<=radius
                n=None
                if radius<epsilon:
                    n=ceiling(2*log_upper/(c*c*(epsilon-radius)**2))
                    assert F(2)*log_upper/F(n)<=c*c*(epsilon-radius)**2
                max_d=max(difference(low,mu,1000,c),difference(high,mu,1000,c))
                row={'e':str(e),'u_mask':u,'cutoff':k,
                     'retained_assignments':int(cal['retained_assignments']),
                     'epsilon':str(epsilon),'delta':str(delta),
                     'sufficient_shots_rational_log_bound':n if n is not None else '',
                     'certified_MSE_improvement_at_m1000_mu3over5':max_d<0}
                exact_fields(row,lambda_exact=lam,lower=low,upper=high,c=c,
                    inversion_radius=radius,actual_bias=(lam/c-1)*mu,
                    bias_floor=(lam/c-1)**2*mu*mu,
                    worst_MSE_difference_at_m1000=max_d,
                    exact_crossing_budget=crossing(lam,mu))
                cert_rows.append(row)
                for m in budgets:
                    raw=raw_mse(lam,mu,m);exact=calibrated_mse(lam,mu,m,lam)
                    actual=calibrated_mse(lam,mu,m,c)
                    bound=max(difference(low,mu,m,c),difference(high,mu,m,c))
                    assert difference(lam,mu,m,c)<=bound
                    row={'e':str(e),'u_mask':u,'cutoff':k,'m':m,'mu':str(mu),
                         'interval_certifies_smaller_MSE':bound<0}
                    exact_fields(row,raw_MSE=raw,exact_calibration_MSE=exact,
                        finite_calibration_MSE=actual,raw_to_calibrated_MSE_ratio=raw/actual,
                        worst_interval_MSE_difference=bound)
                    mse_rows.append(row)
    csv_write(results/'mse_comparison.csv',mse_rows)
    csv_write(results/'observable_certificates.csv',cert_rows)
    csv_write(results/'sampling_overhead.csv',resource_rows)

    # Generate the report tables directly from the verified rational data.
    table=[]
    for e in (F(1,100),F(3,100),F(1,20),F(1,10)):
        ev=evals[e]
        values=[float(e),float(F(ev['lambda']['5'])),float(F(ev['lambda']['10'])),
                float(F(ev['lambda_T']['5'])),float(F(ev['P0']))]
        table.append(' & '.join([f'{values[0]:.2f}']+[f'{x:.8f}' for x in values[1:]])+r' \\')
    (root/'table_characters.tex').write_text('\n'.join(table)+'\n')
    table=[]
    for u in (5,10):
        for k in (1,2,3):
            row=get_cal(F(1,20),u,k)
            table.append(f"{u} & {k} & {row['retained_assignments']} & "
                f"{float(F(row['lambda_lower'])):.9f} & {float(F(row['lambda_upper'])):.9f} "+r'\\')
    (root/'table_intervals.tex').write_text('\n'.join(table)+'\n')
    table=[]
    for u in (5,10):
        row=next(r for r in mse_rows if r['e']=='1/20' and r['u_mask']==u
                 and r['cutoff']==2 and r['m']==1000)
        cert=next(r for r in cert_rows if r['e']=='1/20' and r['u_mask']==u and r['cutoff']==2)
        table.append(f"{u} & {float(F(row['raw_MSE'])):.8f} & "
            f"{float(F(row['exact_calibration_MSE'])):.8f} & "
            f"{float(F(row['finite_calibration_MSE'])):.8f} & "
            f"{float(F(row['raw_to_calibrated_MSE_ratio'])):.2f} "+r'\\')
    (root/'table_mse.tex').write_text('\n'.join(table)+'\n')
    main_cert=next(r for r in cert_rows if r['e']=='1/20' and r['u_mask']==5 and r['cutoff']==2)
    main_mse=next(r for r in mse_rows if r['e']=='1/20' and r['u_mask']==5 and r['cutoff']==2 and r['m']==1000)
    summary={'status':'PASS','arithmetic':'Fraction; no Monte Carlo',
        'main_case':main_cert,'main_mse_at_1000':main_mse,
        'logarithm_certificate':{'log_argument':40,'upper_bound':str(log_upper),
                                'exp_lower_Taylor_terms':20,'verified':exp_lower>40},
        'clipping':'MSE equalities are for the linear unclipped estimator; clipping can only improve its MSE.',
        'scope':'Finite-instance certificate; no uniform KP compiler timing or scalability claim.',
        'tables_generated_from_exact_data':True}
    (results/'analysis_summary.json').write_text(json.dumps(summary,indent=2)+'\n')

    if args.plots:
        import numpy as np
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11.5,
            'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
        fig,axes=plt.subplots(1,2,figsize=(8.8,4.5),sharey=True,layout='constrained')
        shots=np.logspace(0,10,500)
        for ax,u,support in zip(axes,(5,10),('Z0 Z2','Z1 Z3')):
            lam=float(F(evals[F(1,20)]['lambda'][str(u)]));mf=float(mu)
            v=1-lam*lam*mf*mf
            ax.loglog(shots,v/shots+(1-lam)**2*mf*mf,color='#C1692B',lw=2,label='Raw mean')
            ax.loglog(shots,v/(shots*lam*lam),color='#246B90',lw=2,label='Exact coefficient')
            for k,color,style in ((1,'#8061A8','--'),(2,'#28836C','-.')):
                c=float(F(get_cal(F(1,20),u,k)['lambda_midpoint']))
                curve=v/(shots*c*c)+(lam/c-1)**2*mf*mf
                ax.loglog(shots,curve,color=color,ls=style,lw=1.9,label=f'Finite certificate, k={k}')
            threshold=float(crossing(F(evals[F(1,20)]['lambda'][str(u)]),mu))
            ax.axvline(threshold,color='#8A949B',lw=1,ls=':')
            ax.set_title(f'{support}  |  lambda = {lam:.6f}',loc='left',fontweight='bold',fontsize=11.5)
            ax.set_xlabel('Physical executions')
            ax.grid(which='major',axis='both',alpha=.16)
            ax.set_ylim(1e-11,2);ax.set_xlim(1,1e10)
            ax.legend(loc='lower left',fontsize=10,frameon=False)
        axes[0].set_ylabel('Mean squared error')
        fig.suptitle('Finite coefficient precision sets an MSE floor',
                     fontsize=13,fontweight='bold')
        fig.supxlabel('Original circuit; e = 0.05; ideal expectation = 0.6; all outcomes used.\n'
                      'Vertical lines: exact-inversion crossover. Curves are exact moments.',fontsize=10)
        (root/'figures').mkdir(exist_ok=True)
        fig.savefig(root/'figures/mse_vs_shots.png',dpi=220)
        fig.savefig(root/'figures/mse_vs_shots.svg')
        plt.close(fig)
    print('PASS: exact MSE formulas, convex endpoint certificates, and rational Hoeffding budget.')
    for u in (5,10):
        cert=next(r for r in cert_rows if r['e']=='1/20' and r['u_mask']==u and r['cutoff']==2)
        mse=next(r for r in mse_rows if r['e']=='1/20' and r['u_mask']==u and r['cutoff']==2 and r['m']==1000)
        print('u=',u,'radius=',cert['inversion_radius_decimal'],
              'shots=',cert['sufficient_shots_rational_log_bound'],
              'MSE raw=',mse['raw_MSE_decimal'],'MSE calibrated=',mse['finite_calibration_MSE_decimal'],
              'ratio=',mse['raw_to_calibrated_MSE_ratio_decimal'],
              'endpoint certificate=',cert['worst_MSE_difference_at_m1000_decimal'])


if __name__=='__main__':
    main()
