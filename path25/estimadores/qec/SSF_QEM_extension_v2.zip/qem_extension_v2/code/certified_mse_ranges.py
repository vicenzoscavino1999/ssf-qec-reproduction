#!/usr/bin/env python3
"""Rational, interval-only certification of MSE benefit over input states.

No exact attenuation or full noise enumeration is read. The producer uses
the partial coefficient certificate and proves interval-uniform risk signs.
The result characterizes ideal expectations, not an adaptive estimator.
"""
from __future__ import annotations
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal,localcontext
import json
import csv


def decimal(x):
    with localcontext() as c:
        c.prec=35
        return str(Decimal(x.numerator)/Decimal(x.denominator))


def range_certificate(low,high,m):
    c=(low+high)/2
    assert 0<low<=high<=1 and m>=1
    if c==1:return {'status':'estimators_coincide'}
    a=1/(c*c)-1
    g=lambda t:a*(1-F(1,m))*t*t+2*(1-1/c)*t
    gl,gu=g(low),g(high);worst=max(gl,gu)
    if worst>=0:return {'status':'no_uniform_improvement','G':str(worst)}
    tau=a/(-m*worst)
    if tau>=1:return {'status':'no_physical_range','tau':str(tau)}
    with localcontext() as ctx:
        ctx.prec=40
        sqrt_tau=(Decimal(tau.numerator)/Decimal(tau.denominator)).sqrt()
        millistep=int(sqrt_tau*1000)
    while F(millistep,1000)**2<=tau:millistep+=1
    mu0=F(millistep,1000)
    assert a/m+tau*worst==0
    assert a/m+tau*worst/2>0
    assert a/m+(1+tau)*worst/2<0
    margin=a/m+mu0*mu0*worst
    if mu0<=1:assert margin<0
    # Independent direct risk expansion at the boundary and selected range.
    for t in (low,high):
        for mu2 in (tau,F(0),mu0*mu0):
            direct=(1-t*t*mu2)/(m*c*c)+(t/c-1)**2*mu2
            direct-=(1-t*t*mu2)/m+(1-t)**2*mu2
            assert direct==a/m+mu2*g(t)
    return {'status':'certified','c':str(c),'A':str(a),'g_L':str(gl),'g_U':str(gu),
        'G':str(worst),'tau':str(tau),'tau_decimal':decimal(tau),
        'sqrt_tau_decimal':str(sqrt_tau),'closed_range_mu0':str(mu0),
        'closed_range_mu0_decimal':decimal(mu0),'uniform_margin':str(margin),
        'uniform_margin_decimal':decimal(margin)}


def main():
    root=Path(__file__).resolve().parents[1]
    data=json.loads((root/'results/partial_certificate.json').read_text())
    rows=[]
    for u in ('5','10'):
        obs=data['logical_observables'][u]
        for m in (100,1000,10000):
            result=range_certificate(F(obs['lambda_lower']),F(obs['lambda_upper']),m)
            rows.append({'u_mask':u,'m':m,**result})
            if m==1000:
                expected={'5':F(111,1000),'10':F(183,1000)}[u]
                assert F(result['closed_range_mu0'])==expected
                print('u',u,'m',m,'certified |mu| >=',result['closed_range_mu0_decimal'],
                      'uniform risk difference <=',result['uniform_margin_decimal'])
    (root/'results/certified_mse_ranges.json').write_text(json.dumps({
        'source':'partial_certificate.json only','full_enumeration_or_exact_lambda_read':False,
        'linear_estimator':'necessary and sufficient interval-uniform condition',
        'clipped_estimator':'same condition is sufficient',
        'adaptive_selector_claimed':False,'results':rows},indent=2)+'\n')
    with (root/'results/certified_mse_ranges.csv').open('w',newline='') as stream:
        keys=list(dict.fromkeys(k for row in rows for k in row))
        w=csv.DictWriter(stream,fieldnames=keys);w.writeheader();w.writerows(rows)
    print('PASS: exact risk thresholds, closed-range signs, and endpoint certificates.')


if __name__=='__main__':main()
