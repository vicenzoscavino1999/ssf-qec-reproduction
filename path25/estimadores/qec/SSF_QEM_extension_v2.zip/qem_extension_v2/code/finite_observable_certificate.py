#!/usr/bin/env python3
"""Certify protected Z characters without enumerating omitted histories.

Example:
    python finite_observable_certificate.py --e 1/20 --cutoff 2
    python finite_observable_certificate.py --e 1/10 --cutoff 3 --out certificate.json

The four physical noisy locations have 15, 3, 3, and 7 nonbaseline
alternatives. We generate subsets of at most cutoff locations directly,
then only their nonbaseline categorical alternatives. Each retained history
is propagated and decoded once. At cutoff 2 this is 275 histories.

The readout is one joint (Pauli, flip) location. Its baseline mass is
(1-e)^2, so the analytic omitted mass is the upper tail of the sum of
three Bernoulli(e) variables and one Bernoulli(2e-e^2) variable.

The imported fixture supplies the exact circuit and full SSF rule. Its
module-level setup prepares four syndrome decodings, but neither complete
history enumerator is called. No results JSON, CSV, or complete spectrum
is read. This is a finite certificate, not a KP implementation.
"""

from __future__ import annotations

import argparse
import json
from collections import Counter
from fractions import Fraction
from itertools import combinations, product
from math import comb, prod
from pathlib import Path

import exact_qem_fixture as fixture


BASELINES = (("I", "I"), "I", "I", ("I", 0))
ALTERNATIVES = (
    tuple(pair for pair in product(fixture.PAULIS, repeat=2)
          if pair != BASELINES[0]),
    tuple(p for p in fixture.PAULIS if p != "I"),
    tuple(p for p in fixture.PAULIS if p != "I"),
    tuple(pair for pair in product(fixture.PAULIS, (0, 1))
          if pair != BASELINES[3]),
)
assert tuple(map(len, ALTERNATIVES)) == (15, 3, 3, 7)


def retained_histories(cutoff):
    """Generate retained categories directly; never generate omitted ones."""
    for active_count in range(cutoff + 1):
        for active_sites in combinations(range(4), active_count):
            for active_categories in product(*(ALTERNATIVES[i] for i in active_sites)):
                history = list(BASELINES)
                for i, category in zip(active_sites, active_categories):
                    history[i] = category
                yield active_count, tuple(history)


def history_probability(history, e):
    gate, wait0, wait1, readout = history
    readout_pauli, flip = readout
    gate_probability = 1-e if gate == ("I", "I") else e/15

    def one_qubit_pauli_probability(label):
        return 1-e if label == "I" else e/3

    return (gate_probability
            * one_qubit_pauli_probability(wait0)
            * one_qubit_pauli_probability(wait1)
            * one_qubit_pauli_probability(readout_pauli)
            * (e if flip else 1-e))


def analytic_retained_mass(e, cutoff):
    readout_nonbaseline = 2*e-e*e
    return sum(
        (Fraction(comb(3, j))
         * e**j * (1-e)**(3-j)
         * readout_nonbaseline**b * (1-readout_nonbaseline)**(1-b))
        for j in range(4) for b in (0, 1) if j+b <= cutoff
    )


def combinatorial_retained_count(cutoff):
    return sum(
        prod(len(ALTERNATIVES[i]) for i in sites)
        for count in range(cutoff+1)
        for sites in combinations(range(4), count)
    )


def certify(e, cutoff):
    if not 0 <= e <= 1:
        raise ValueError("e must lie in [0,1].")
    if not 0 <= cutoff <= 4:
        raise ValueError("cutoff must be an integer in {0,1,2,3,4}.")
    retained_mass = Fraction(0)
    signed_sums = {u: Fraction(0) for u in fixture.LOGICAL_Z}
    propagated = decoded = 0
    by_active_count = Counter()
    for active_count, history in retained_histories(cutoff):
        gate, wait0, wait1, readout = history
        gate_control, gate_target = gate
        readout_pauli, flip = readout
        weight = history_probability(history, e)
        data_x, data_z, observed = fixture.literal_pauli_propagation(
            gate_control, gate_target, wait0, wait1, readout_pauli, flip)
        propagated += 1
        correction, trace = fixture.decode(observed)
        decoded += 1
        residual = data_x ^ correction
        retained_mass += weight
        by_active_count[active_count] += 1
        for u in signed_sums:
            signed_sums[u] += (1-2*fixture.parity(u & residual))*weight

    expected_count = combinatorial_retained_count(cutoff)
    assert propagated == decoded == expected_count
    exact_retained_mass = analytic_retained_mass(e, cutoff)
    assert retained_mass == exact_retained_mass
    tail = 1-exact_retained_mass
    observables = {}
    for u, signed in signed_sums.items():
        lower = max(Fraction(-1), signed-tail)
        upper = min(Fraction(1), signed+tail)
        midpoint = (lower+upper)/2
        values = {"signed_retained_sum": signed,
                  "lambda_lower": lower,
                  "lambda_upper": upper,
                  "lambda_midpoint": midpoint}
        observables[str(u)] = {
            "u_mask": u,
            "u_support": [v for v in range(fixture.N) if (u >> v) & 1],
            **{name: str(value) for name, value in values.items()},
            **{name+"_decimal": fixture.decimal_text(value)
               for name, value in values.items()},
        }
    return {
        "model": "original_appendix_G_circuit",
        "method": "Direct generation of retained categorical histories only",
        "e": str(e),
        "e_decimal": fixture.decimal_text(e),
        "cutoff_nonbaseline_locations": cutoff,
        "nonbaseline_alternatives_by_location": list(map(len, ALTERNATIVES)),
        "readout_baseline_probability": str((1-e)**2),
        "readout_nonbaseline_probability": str(2*e-e*e),
        "retained_assignments": expected_count,
        "propagated_histories": propagated,
        "decoded_histories": decoded,
        "retained_counts_by_nonbaseline_locations": dict(sorted(by_active_count.items())),
        "full_space_size_by_alphabet_product": prod(len(a)+1 for a in ALTERNATIVES),
        "omitted_histories_generated": 0,
        "omitted_histories_propagated": 0,
        "omitted_histories_decoded": 0,
        "complete_spectra_or_results_read": False,
        "retained_probability": str(retained_mass),
        "retained_probability_decimal": fixture.decimal_text(retained_mass),
        "tail": str(tail),
        "tail_decimal": fixture.decimal_text(tail),
        "analytic_tail_method": "Sum of 3 Bernoulli(e) variables and 1 Bernoulli(2e-e^2)",
        "retained_mass_matches_independent_analytic_mass": True,
        "logical_observables": observables,
        "scope": "Finite character certificate only; no uniform KP or scaling claim.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--e", type=Fraction, default=Fraction(1, 20),
                        help="rational depolarizing/flip rate, e.g. 1/20")
    parser.add_argument("--cutoff", type=int, default=2,
                        help="maximum number of nonbaseline physical locations, 0..4")
    parser.add_argument(
        "--out", type=Path,
        default=Path(__file__).resolve().parent.parent / "results" / "partial_certificate.json",
        help="destination JSON file")
    args = parser.parse_args()
    if not 0 <= args.e <= 1 or not 0 <= args.cutoff <= 4:
        parser.error("require 0 <= e <= 1 and 0 <= cutoff <= 4")
    result = certify(args.e, args.cutoff)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2, sort_keys=True)+"\n", encoding="utf-8")
    print("PASS: retained probability equals the independent analytic mass.")
    print("propagated_histories =", result["propagated_histories"])
    print("decoded_histories =", result["decoded_histories"])
    print("omitted_histories_generated = 0")
    print("tail =", result["tail"])
    for u, values in result["logical_observables"].items():
        print("u =", u, "interval =",
              "["+values["lambda_lower"]+", "+values["lambda_upper"]+"]")
    print("Output:", args.out.resolve())


if __name__ == "__main__":
    main()
