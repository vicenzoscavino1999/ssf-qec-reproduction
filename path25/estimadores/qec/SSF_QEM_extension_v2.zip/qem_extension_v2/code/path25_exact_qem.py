#!/usr/bin/env python3
"""PATH25: exact finite observable calibration with a connected adaptive SSF.

Python 3.10+, standard library only:
    python path25_exact_qem.py --out .
    python path25_exact_qem.py --certificate-only --cutoff 2 --out .

The second command generates only 704 low-weight histories, skips Walsh
reference values, and constructs its intervals and MSE comparison solely
from the retained sums and the analytic tail. Preparing the full table
of 4096 syndrome decodings is still charged in that mode.

Source: manuscript Section 2 and Appendix F, PATH25 seed rows (3,6,12).
The nonregular seed uses every nonempty generator subset with nonempty
footprint, without the regular FGL filter. The full decoder has beta=1/2,
score (2|s intersect phi|-|phi|)/|phi|, and ascending (|F|,mask(F)) ties.

The manuscript's PATH25 calculations use q=0. The p,q>0 computations here
are an explicitly specified phenomenological extension using the same
code and exact decoder; they are not a circuit-level implementation.

We enumerate 4096 syndromes, not 2^25 errors or 2^37 fault histories.
Exact characters use integer Walsh-Hadamard transforms with a common
denominator. A separate catalogue directly generates only fault supports
of total weight <=3 (8474 histories), with an analytic omitted mass.
This is exponential in the number of checks, not a KP implementation
or a demonstration of growing-family scalability.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from collections import Counter
from decimal import Decimal, localcontext
from fractions import Fraction as F
from functools import lru_cache
from itertools import combinations, product
from math import comb
from pathlib import Path
from time import perf_counter


SEED = (3, 6, 12)
SEED_COLUMNS = 4
PRIMARY_POINTS = ((F(1, 100), F(1, 200)),
                  (F(1, 50), F(1, 100)),
                  (F(3, 100), F(1, 100)))
MU = F(3, 5)


def parity(mask):
    return mask.bit_count() & 1


def syndrome(mask, rows):
    return sum(parity(mask & row) << j for j, row in enumerate(rows))


def rowspace(rows):
    result = {0}
    for row in rows:
        result |= {x ^ row for x in tuple(result)}
    return result


def rowspace_by_coefficient(rows):
    values = [0] * (1 << len(rows))
    for a in range(1, len(values)):
        bit = a & -a
        values[a] = values[a ^ bit] ^ rows[bit.bit_length()-1]
    return values


def hgp(seed, a):
    b = len(seed)
    hx = []
    for i in range(a):
        for c in range(b):
            row = sum(1 << (i*a+j) for j in range(a) if (seed[c] >> j) & 1)
            row |= sum(1 << (a*a+d*b+c) for d in range(b) if (seed[d] >> i) & 1)
            hx.append(row)
    hz = []
    for c in range(b):
        for j in range(a):
            row = sum(1 << (i*a+j) for i in range(a) if (seed[c] >> i) & 1)
            row |= sum(1 << (a*a+c*b+d) for d in range(b) if (seed[d] >> j) & 1)
            hz.append(row)
    return a*a+b*b, tuple(hx), tuple(hz)


class Decoder:
    def __init__(self, n, hx, hz, beta=F(1, 2), tie="size", fgl_A=None):
        self.n, self.hx, self.hz = n, tuple(hx), tuple(hz)
        self.m, self.beta = len(hx), beta
        candidates = set()
        for generator in hz:
            subset = generator
            while subset:
                footprint = syndrome(subset, hx)
                if footprint and (fgl_A is None
                                  or 2*footprint.bit_count() >= fgl_A*subset.bit_count()):
                    candidates.add(subset)
                subset = (subset-1) & generator
        sort_key = ((lambda mask: (mask.bit_count(), mask)) if tie == "size"
                    else (lambda mask: (-syndrome(mask, hx).bit_count(), mask)))
        self.candidates = tuple(sorted(candidates, key=sort_key))
        self.rank = {f: i for i, f in enumerate(self.candidates)}
        self.phi = {f: syndrome(f, hx) for f in self.candidates}
        self.den = {f: self.phi[f].bit_count() for f in self.candidates}
        self.winner = []
        for s in range(1 << self.m):
            chosen = self.step_integer(s)
            assert chosen == self.step_fraction(s)
            self.winner.append(chosen)

        @lru_cache(maxsize=None)
        def trace(s):
            f = self.winner[s]
            if f is None:
                return 0, (), s
            nxt = s ^ self.phi[f]
            assert nxt.bit_count() < s.bit_count()
            c, rest, terminal = trace(nxt)
            return c ^ f, (f,)+rest, terminal

        self.corrections = []
        self.traces = []
        self.terminals = []
        self.action_unions = []
        for s in range(1 << self.m):
            c, steps, terminal = trace(s)
            assert syndrome(c, hx) == s ^ terminal
            self.corrections.append(c)
            self.traces.append(steps)
            self.terminals.append(terminal)
            union = 0
            for f in steps:
                union |= f
            self.action_unions.append(union)

    def step_integer(self, s):
        best, best_num, best_den = None, None, None
        for f in self.candidates:
            denominator = self.den[f]
            numerator = 2*(s & self.phi[f]).bit_count()-denominator
            if best is None or numerator*best_den > best_num*denominator:
                best, best_num, best_den = f, numerator, denominator
        if best is None or best_num*self.beta.denominator < self.beta.numerator*best_den:
            return None
        return best

    def step_fraction(self, s):
        # Independent score arithmetic and comparison; preserve the first tied rank.
        maximum, winner = None, None
        for f in self.candidates:
            score = F(2*(s & self.phi[f]).bit_count()-self.den[f], self.den[f])
            if maximum is None or score > maximum:
                maximum, winner = score, f
        return winner if maximum is not None and maximum >= self.beta else None

    def select_head(self, s, heads):
        return min(heads, key=lambda f:
                   (-F(2*(s & self.phi[f]).bit_count()-self.den[f], self.den[f]),
                    self.rank[f]))


def make_host(decoder):
    n, m = decoder.n, decoder.m
    responses = [syndrome(1 << v, decoder.hx) for v in range(n)]
    responses += [1 << c for c in range(m)]
    adj = [0]*(n+m)
    for f in decoder.candidates:
        phi = decoder.phi[f]
        readers = [x for x, response in enumerate(responses) if response & phi]
        reader_mask = sum(1 << x for x in readers)
        data_targets = [v for v in range(n) if (f >> v) & 1]
        for x in readers:
            adj[x] |= reader_mask & ~(1 << x)
            adj[x] |= f & ~(1 << x)
        for v in data_targets:
            adj[v] |= reader_mask & ~(1 << v)
    for x, neighbors in enumerate(adj):
        assert not (neighbors >> x) & 1
        for y in range(n+m):
            assert ((neighbors >> y) & 1) == ((adj[y] >> x) & 1)
    return tuple(adj)


def components(support, adj):
    remaining = support
    result = []
    while remaining:
        start = remaining & -remaining
        remaining ^= start
        seen, frontier = start, start
        while frontier:
            bit = frontier & -frontier
            frontier ^= bit
            v = bit.bit_length()-1
            reached = adj[v] & remaining
            remaining ^= reached
            seen |= reached
            frontier |= reached
        result.append(seen)
    return result


def verify_component_recomposition(e, d, parts, decoder):
    n, data_mask = decoder.n, (1 << decoder.n)-1
    local_traces = []
    combined_correction = 0
    for part in parts:
        local_e = e & part & data_mask
        local_d = d & (part >> n)
        local_s = syndrome(local_e, decoder.hx) ^ local_d
        trace = decoder.traces[local_s]
        exact_support = local_e | (local_d << n) | decoder.action_unions[local_s]
        assert exact_support == part
        combined_correction ^= decoder.corrections[local_s]
        local_traces.append(trace)
    initial = syndrome(e, decoder.hx) ^ d
    assert combined_correction == decoder.corrections[initial]
    indices = [0]*len(local_traces)
    s, merged = initial, []
    while any(indices[j] < len(trace) for j, trace in enumerate(local_traces)):
        heads = [trace[indices[j]] for j, trace in enumerate(local_traces)
                 if indices[j] < len(trace)]
        winner = decoder.select_head(s, heads)
        assert decoder.winner[s] == winner
        owners = [j for j, trace in enumerate(local_traces)
                  if indices[j] < len(trace) and trace[indices[j]] == winner]
        assert len(owners) == 1
        indices[owners[0]] += 1
        merged.append(winner)
        s ^= decoder.phi[winner]
    assert tuple(merged) == decoder.traces[initial]


def character_nonlinearity(u, decoder):
    bits = [parity(u & c) for c in decoder.corrections]
    assert bits[0] == 0
    linear_mask = sum(bits[1 << j] << j for j in range(decoder.m))
    disagreements = [s for s, bit in enumerate(bits) if bit != parity(linear_mask & s)]
    return {"linear_candidate_mask": linear_mask,
            "disagreement_count": len(disagreements),
            "first_counterexample": disagreements[0] if disagreements else None,
            "is_linear": not disagreements}


def fwht(values):
    result = list(values)
    block = 1
    while block < len(result):
        for start in range(0, len(result), 2*block):
            for j in range(start, start+block):
                left, right = result[j], result[j+block]
                result[j] = left+right
                result[j+block] = left-right
        block *= 2
    return result


def walsh_exact(decoder, masks, p, q):
    """Integer FWT. G_u(t)=E[(-1)^(u.E) 1_{HX E=t}], exactly."""
    n, m, length = decoder.n, decoder.m, 1 << decoder.m
    alpha, gamma = 1-2*p, 1-2*q
    dual = rowspace_by_coefficient(decoder.hx)
    common_data_den = alpha.denominator**n
    alpha_powers = [alpha.numerator**w * alpha.denominator**(n-w)
                    for w in range(n+1)]
    gamma_powers = [gamma.numerator**w * gamma.denominator**(m-w)
                    for w in range(m+1)]
    d_powers = [q.numerator**w * (q.denominator-q.numerator)**(m-w)
                for w in range(m+1)]
    all_masks = tuple(dict.fromkeys((0,)+tuple(masks)))
    g, h = {}, {}
    for u in all_masks:
        spectral = [alpha_powers[(u ^ vector).bit_count()] for vector in dual]
        g[u] = fwht(spectral)
        h[u] = fwht([value*gamma_powers[a.bit_count()]
                    for a, value in enumerate(spectral)])
    data_den = length*common_data_den
    joint_den = data_den*gamma.denominator**m
    filter_den = data_den*q.denominator**m
    assert all(value >= 0 for value in g[0])
    assert all(value >= 0 for value in h[0])
    assert sum(g[0]) == data_den
    assert sum(h[0]) == joint_den
    for u in masks:
        assert all(abs(value) <= g[0][j] for j, value in enumerate(g[u]))
        assert all(abs(value) <= h[0][j] for j, value in enumerate(h[u]))
        assert F(sum(g[u]), data_den) == alpha**u.bit_count()
        assert F(sum(h[u]), joint_den) == alpha**u.bit_count()

    accept_numerator = 0
    filtered_numerators = {u: 0 for u in masks}
    raw_numerators = {u: 0 for u in masks}
    for s, correction in enumerate(decoder.corrections):
        b = syndrome(correction, decoder.hx)
        d = s ^ b
        d_weight = d_powers[d.bit_count()]
        accept_numerator += d_weight*g[0][b]
        for u in masks:
            sign = 1-2*parity(u & correction)
            raw_numerators[u] += sign*h[u][s]
            filtered_numerators[u] += sign*d_weight*g[u][b]
    p0 = F(accept_numerator, filter_den)
    assert 0 < p0 <= 1
    observables = {}
    for u in masks:
        lam = F(raw_numerators[u], joint_den)
        numerator = F(filtered_numerators[u], filter_den)
        lam_t = numerator/p0
        assert -1 <= lam <= 1 and -1 <= lam_t <= 1
        observables[u] = {"lambda": lam, "filtered_numerator": numerator,
                          "lambda_T": lam_t, "Qsil": (1-lam_t)/2,
                          "Psil": (p0-numerator)/2}
    if q == 0:
        # Independent specialization: only genuinely cleared initial syndromes survive.
        valid = [s for s, terminal in enumerate(decoder.terminals) if terminal == 0]
        assert p0 == F(sum(g[0][s] for s in valid), data_den)
        for u in masks:
            direct = sum((1-2*parity(u & decoder.corrections[s]))*g[u][s]
                         for s in valid)
            assert observables[u]["filtered_numerator"] == F(direct, data_den)
    if p == 0:
        direct_p0 = sum(
            q**s.bit_count()*(1-q)**(m-s.bit_count())
            for s, winner in enumerate(decoder.winner) if winner is None)
        assert p0 == direct_p0
        assert all(values["lambda_T"] == 1 and values["Psil"] == 0
                   for values in observables.values())
    return {"P0": p0, "observables": observables,
            "validation": {"syndrome_distributions_nonnegative_and_normalized": True,
                           "signed_masses_bounded_by_unsigned_masses": True,
                           "character_marginals_correct": True}}


def enumerate_low_weight_catalogue(decoder, masks, cutoff, adj):
    n, total_sites, spectra = decoder.n, decoder.n+decoder.m, {}
    sx = rowspace(decoder.hz)
    total = 0
    component_histogram = Counter()
    step_histogram = Counter()
    multi_component = multi_component_with_actions = multi_component_with_two_actions = 0
    multi_local_active_traces = 0
    examples = {}
    for weight in range(cutoff+1):
        for sites in combinations(range(total_sites), weight):
            source = sum(1 << site for site in sites)
            e, d = source & ((1 << n)-1), source >> n
            s = syndrome(e, decoder.hx) ^ d
            correction = decoder.corrections[s]
            residual = e ^ correction
            accepted = syndrome(residual, decoder.hx) == 0
            bad = accepted and residual not in sx
            i, j = e.bit_count(), d.bit_count()
            counts = spectra.setdefault((i, j),
                {"total": 0, "accepted": 0, "silent_failure": 0,
                 "signed": {u: 0 for u in masks},
                 "filtered_signed": {u: 0 for u in masks}})
            counts["total"] += 1
            counts["accepted"] += int(accepted)
            counts["silent_failure"] += int(bad)
            for u in masks:
                sign = 1-2*parity(u & residual)
                counts["signed"][u] += sign
                counts["filtered_signed"][u] += sign*accepted
                if accepted:
                    assert sign == 1-2*bad
            support = source | decoder.action_unions[s]
            parts = components(support, adj)
            component_histogram[len(parts)] += 1
            step_histogram[len(decoder.traces[s])] += 1
            if len(parts) >= 2:
                multi_component += 1
                verify_component_recomposition(e, d, parts, decoder)
                if decoder.traces[s]:
                    multi_component_with_actions += 1
                if len(decoder.traces[s]) >= 2:
                    multi_component_with_two_actions += 1
                active_local = sum(
                    bool(decoder.traces[syndrome(e & part, decoder.hx) ^ (d & (part >> n))])
                    for part in parts)
                if active_local >= 2:
                    multi_local_active_traces += 1
                    examples.setdefault("multiple_active_components",
                        {"E_mask": e, "D_mask": d, "initial_syndrome": s,
                         "trace": decoder.traces[s], "execution_components": parts})
            if len(decoder.traces[s]) >= 2:
                examples.setdefault("multiple_actions",
                    {"E_mask": e, "D_mask": d, "initial_syndrome": s,
                     "trace": decoder.traces[s], "execution_components": parts})
            total += 1
    assert total == sum(comb(total_sites, k) for k in range(cutoff+1))
    for (i, j), counts in spectra.items():
        assert counts["total"] == comb(n, i)*comb(decoder.m, j)
    return spectra, {
        "fault_supports_enumerated": total, "max_fault_weight": cutoff,
        "histories_by_number_of_execution_components": dict(sorted(component_histogram.items())),
        "histories_by_number_of_actions": dict(sorted(step_histogram.items())),
        "multi_component_histories": multi_component,
        "multi_component_histories_with_actions": multi_component_with_actions,
        "multi_component_histories_with_at_least_two_actions": multi_component_with_two_actions,
        "histories_with_at_least_two_active_local_traces": multi_local_active_traces,
        "restriction_and_canonical_merge_verified_for_all_multi_component_histories": True,
        "examples": examples,
        "comparison_scope": f"This is a new complete source catalogue of weight <={cutoff}, not the manuscript's selected set of 565 sources."
    }


def evaluate_catalogue(decoder, masks, spectra, cutoff, p, q, exact=None):
    n, m = decoder.n, decoder.m
    signed = {u: F(0) for u in masks}
    filtered_signed = {u: F(0) for u in masks}
    mass = accepted_mass = failed_mass = F(0)
    histories = 0
    for (i, j), counts in spectra.items():
        if i+j > cutoff:
            continue
        weight = p**i*(1-p)**(n-i)*q**j*(1-q)**(m-j)
        mass += counts["total"]*weight
        accepted_mass += counts["accepted"]*weight
        failed_mass += counts["silent_failure"]*weight
        histories += counts["total"]
        for u in masks:
            signed[u] += counts["signed"][u]*weight
            filtered_signed[u] += counts["filtered_signed"][u]*weight
    analytic = sum(
        F(comb(n, i)*comb(m, j))*p**i*(1-p)**(n-i)*q**j*(1-q)**(m-j)
        for i in range(cutoff+1) for j in range(cutoff+1-i))
    assert mass == analytic
    assert histories == sum(comb(n+m, k) for k in range(cutoff+1))
    tail = 1-mass
    results = {}
    for u in masks:
        low, high = max(F(-1), signed[u]-tail), min(F(1), signed[u]+tail)
        midpoint = (low+high)/2
        # For the conditional interval, omitted accepted signs can be allocated
        # wholly positive or wholly negative; no exact P0 is needed.
        low_t = (filtered_signed[u]-tail)/(accepted_mass+tail)
        high_t = (filtered_signed[u]+tail)/(accepted_mass+tail)
        if exact is not None:
            # Optional reference validation, never used to construct an interval.
            lam = exact["observables"][u]["lambda"]
            assert low <= lam <= high
            assert low_t <= exact["observables"][u]["lambda_T"] <= high_t
            assert accepted_mass <= exact["P0"] <= accepted_mass+tail
        results[u] = {"signed_retained_sum": signed[u],
                      "lambda_lower": low, "lambda_upper": high,
                      "lambda_midpoint": midpoint,
                      "filtered_signed_retained_sum": filtered_signed[u],
                      "lambda_T_lower": low_t, "lambda_T_upper": high_t}
    return {"cutoff": cutoff, "retained_histories": histories,
            "retained_mass": mass, "tail": tail,
            "accepted_retained_mass": accepted_mass,
            "silent_failure_retained_mass": failed_mass,
            "observables": results}


def validate_five_qubit_walsh():
    decoder = Decoder(5, (19, 28), (21, 26), F(1, 100), "footprint", fgl_A=1)
    masks = (5, 10, 22, 25)
    sx = rowspace(decoder.hz)
    cases = PRIMARY_POINTS+((F(0), F(1, 100)), (F(1, 100), F(0)), (F(0), F(0)))
    for p, q in cases:
        exact = walsh_exact(decoder, masks, p, q)
        p0 = F(0)
        lam = {u: F(0) for u in masks}
        numerator = {u: F(0) for u in masks}
        failed = F(0)
        for e, d in product(range(32), range(4)):
            weight = p**e.bit_count()*(1-p)**(5-e.bit_count())
            weight *= q**d.bit_count()*(1-q)**(2-d.bit_count())
            s = syndrome(e, decoder.hx) ^ d
            residual = e ^ decoder.corrections[s]
            accepted = syndrome(residual, decoder.hx) == 0
            p0 += accepted*weight
            failed += (accepted and residual not in sx)*weight
            for u in masks:
                sign = 1-2*parity(u & residual)
                lam[u] += sign*weight
                numerator[u] += sign*accepted*weight
        assert p0 == exact["P0"] == (1-q)**2
        for u in masks:
            observed = exact["observables"][u]
            assert observed["lambda"] == lam[u]
            assert observed["filtered_numerator"] == numerator[u]
            assert observed["Psil"] == failed
            assert observed["lambda_T"] == (1-2*p)**2
            q_power = {5: 2, 10: 0, 22: 1, 25: 1}[u]
            assert observed["lambda"] == (1-2*p)**2*(1-2*q)**q_power
    return {"direct_histories_per_case": 128, "parameter_cases": len(cases),
            "protected_representatives": masks,
            "direct_enumeration_and_known_closed_formulas_agree_exactly": True}


def serialize(obj):
    if isinstance(obj, F):
        return str(obj)
    if isinstance(obj, dict):
        return {str(k): serialize(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [serialize(x) for x in obj]
    return obj


def decimal_text(value):
    with localcontext() as ctx:
        ctx.prec = 24
        return str(Decimal(value.numerator)/Decimal(value.denominator))


def attach_numbers(row, values):
    for key, value in values.items():
        row[key] = str(value)
        row[key+"_decimal"] = decimal_text(value)
    return row


def write_csv(path, rows):
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def risk_certificate(lower, upper, estimate, shots, mu=MU):
    if estimate == 0:
        raise ValueError("A zero calibration estimate cannot be inverted.")
    def calibrated(at):
        return mu*mu*(at/estimate-1)**2+(1-mu*mu*at*at)/(shots*estimate*estimate)
    worst_calibrated = max(calibrated(lower), calibrated(upper))
    candidates = [lower, upper]
    if shots > 1:
        vertex = F(shots, shots-1)
        if lower <= vertex <= upper:
            candidates.append(vertex)
    best_raw = min(mu*mu*(at-1)**2+(1-mu*mu*at*at)/shots for at in candidates)
    return {"shots": shots, "mu": mu,
            "worst_calibrated_MSE": worst_calibrated,
            "best_raw_MSE": best_raw,
            "strict_gain_certified": worst_calibrated < best_raw}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--cutoff", type=int, choices=(2, 3), default=3,
                        help="maximum total source weight generated, 2 or 3")
    parser.add_argument("--certificate-only", action="store_true",
                        help="skip Walsh values and construct finite certificates without exact references")
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    started = perf_counter()
    n, hx, hz = hgp(SEED, SEED_COLUMNS)
    assert n == 25 and len(hx) == len(hz) == 12
    sx, sz = rowspace(hz), rowspace(hx)
    assert len(rowspace(SEED)) == 8
    assert len(sx) == len(sz) == 4096
    assert all(syndrome(g, hx) == 0 for g in hz)
    u_control = sum(1 << (4*i) for i in range(4))
    u_adaptive = u_control ^ hx[1]
    masks = (u_control, u_adaptive)
    witness_x = 15
    assert masks == (4369, 135447)
    assert syndrome(witness_x, hx) == 0 and witness_x not in sx
    for u in masks:
        assert syndrome(u, hz) == 0 and u not in sz
        assert parity(u & witness_x) == 1
        assert all(parity(u & x) == 0 for x in sx)
    kernel = sx | {s ^ witness_x for s in sx}
    assert len(kernel) == 8192
    assert all(syndrome(r, hx) == 0 for r in kernel)
    for r in kernel:
        assert all(parity(u & r) == (r not in sx) for u in masks)

    decoder = Decoder(n, hx, hz)
    assert len(decoder.candidates) == 103
    decoder_time = perf_counter()-started
    action_hist = dict(sorted(Counter(map(len, decoder.traces)).items()))
    expected_action_hist = {0: 8, 1: 83, 2: 357, 3: 834, 4: 1162,
                            5: 991, 6: 505, 7: 140, 8: 16}
    assert action_hist == expected_action_hist
    correction_hash = hashlib.sha256(
        json.dumps(decoder.corrections, separators=(",", ":")).encode()).hexdigest()
    assert correction_hash == "6b9b6a523b4407bf4ffa4ddcdccbe0a566c2be206c4c5d263cb6ffc20ba647a6"
    nonlinear = {u: character_nonlinearity(u, decoder) for u in masks}
    assert nonlinear[u_control]["is_linear"]
    assert nonlinear[u_control]["linear_candidate_mask"] == 585
    assert nonlinear[u_adaptive]["disagreement_count"] == 1280

    adj = make_host(decoder)
    host_stats = {"vertices": n+decoder.m,
                  "edges": sum(x.bit_count() for x in adj)//2,
                  "max_degree": max(x.bit_count() for x in adj),
                  "connected": len(components((1 << (n+decoder.m))-1, adj)) == 1,
                  "data_induced_connected": len(components((1 << n)-1, adj)) == 1,
                  "data_induced_complete": all(
                      (adj[v] & ((1 << n)-1)).bit_count() == n-1 for v in range(n))}
    assert host_stats["connected"] and host_stats["data_induced_connected"]
    assert not host_stats["data_induced_complete"]
    catalogue_start = perf_counter()
    spectra, catalogue_stats = enumerate_low_weight_catalogue(decoder, masks, args.cutoff, adj)
    catalogue_time = perf_counter()-catalogue_start
    assert catalogue_stats["fault_supports_enumerated"] == {2: 704, 3: 8474}[args.cutoff]
    cutoffs = tuple(k for k in (2, 3) if k <= args.cutoff)
    if args.certificate_only:
        partial_results, partial_rows = [], []
        for p, q in PRIMARY_POINTS:
            for cutoff in cutoffs:
                certificate = evaluate_catalogue(
                    decoder, masks, spectra, cutoff, p, q, exact=None)
                risks = {}
                for u in masks:
                    obs = certificate["observables"][u]
                    risks[u] = risk_certificate(
                        obs["lambda_lower"], obs["lambda_upper"],
                        obs["lambda_midpoint"], shots=1000)
                    partial_rows.append(attach_numbers(
                        {"p": str(p), "q": str(q), "u_mask": u, "cutoff": cutoff,
                         "retained_histories": certificate["retained_histories"]},
                        {"retained_mass": certificate["retained_mass"],
                         "tail": certificate["tail"], **obs}))
                partial_results.append({"p": p, "q": q, "certificate": certificate,
                                        "MSE_comparison_using_interval_only": risks})
        partial_payload = {
            "mode": "finite_certificate_only",
            "source": "PATH25 Appendix F; independent Bernoulli p,q extension",
            "seed_rows": SEED, "seed_columns": SEED_COLUMNS,
            "n": n, "m": decoder.m, "HX": hx, "HZ": hz,
            "candidate_count": len(decoder.candidates),
            "beta": F(1, 2), "tie_order": "(|F|, mask(F))",
            "score_denominator": "|HX F|",
            "decoder_syndromes_prepared": 4096,
            "correction_table_sha256": correction_hash,
            "logical_Z_representatives": masks,
            "walsh_reference_executed": False,
            "exact_reference_values_or_files_used": False,
            "direct_source_histories_generated": catalogue_stats["fault_supports_enumerated"],
            "maximum_source_weight_generated": args.cutoff,
            "source_histories_above_cutoff_generated": 0,
            "catalogue": catalogue_stats,
            "results": partial_results,
            "scope": "Finite certificate; full decoder-table preparation is charged; no KP or scaling claim."
        }
        destination = args.out/"path25_partial_certificate.json"
        destination.write_text(
            json.dumps(serialize(partial_payload), indent=2, sort_keys=True)+"\n",
            encoding="utf-8")
        write_csv(args.out/"path25_partial_certificate.csv", partial_rows)
        print("PASS: finite intervals constructed without Walsh or exact reference probabilities.")
        print("Decoder syndromes prepared:", 4096)
        print("Direct source histories generated:", catalogue_stats["fault_supports_enumerated"])
        print("Source histories above cutoff generated:", 0)
        print("Output:", destination.resolve())
        return
    five_qubit_validation = validate_five_qubit_walsh()
    validation_points = ((F(1, 100), F(0)), (F(0), F(1, 100)), (F(0), F(0)))
    evaluations = []
    metrics_rows, certificate_rows, mse_rows = [], [], []
    walsh_start = perf_counter()
    for p, q in PRIMARY_POINTS+validation_points:
        exact = walsh_exact(decoder, masks, p, q)
        assert exact["observables"][u_control]["lambda"] == (1-2*p)**4*(1-2*q)**4
        assert (exact["observables"][u_control]["lambda_T"]
                == exact["observables"][u_adaptive]["lambda_T"])
        certificates = [evaluate_catalogue(decoder, masks, spectra, k, p, q, exact)
                        for k in cutoffs]
        primary = (p, q) in PRIMARY_POINTS
        evaluations.append({"p": p, "q": q, "primary_example": primary,
                            "exact": exact, "certificates": certificates})
        for u in masks:
            values = exact["observables"][u]
            row = {"p": str(p), "q": str(q), "u_mask": u, "u_weight": u.bit_count(),
                   "primary_example": primary, "correction_character_linear": nonlinear[u]["is_linear"]}
            metrics_rows.append(attach_numbers(row,
                {"P0": exact["P0"], **values, "observed_mean_mu_3_over_5": MU*values["lambda"]}))
            for cert in certificates:
                obs = cert["observables"][u]
                row = {"p": str(p), "q": str(q), "u_mask": u,
                       "cutoff": cert["cutoff"], "retained_histories": cert["retained_histories"],
                       "primary_example": primary}
                certificate_rows.append(attach_numbers(row,
                    {"lambda_exact": values["lambda"], "P0_exact": exact["P0"],
                     "retained_mass": cert["retained_mass"], "tail": cert["tail"], **obs}))
                if not primary:
                    continue
                lam, estimate = values["lambda"], obs["lambda_midpoint"]
                lower, upper = obs["lambda_lower"], obs["lambda_upper"]
                if estimate == 0:
                    continue
                for shots in (100, 1000, 10000):
                    def calibrated_risk(at):
                        return MU*MU*(at/estimate-1)**2+(1-MU*MU*at*at)/(shots*estimate*estimate)
                    raw = MU*MU*(lam-1)**2+(1-MU*MU*lam*lam)/shots
                    exact_risk = (1/(lam*lam)-MU*MU)/shots
                    risk = calibrated_risk(lam)
                    worst = max(calibrated_risk(lower), calibrated_risk(upper))
                    # Both quadratics are convex, but the raw MSE minimum
                    # over lambda in [lower,upper] may be at its vertex.
                    candidates = [lower, upper]
                    if shots > 1:
                        vertex = F(shots, shots-1)
                        if lower <= vertex <= upper:
                            candidates.append(vertex)
                    raw_lower = min(MU*MU*(at-1)**2+(1-MU*MU*at*at)/shots
                                    for at in candidates)
                    mse_rows.append(attach_numbers(
                        {"p": str(p), "q": str(q), "u_mask": u, "cutoff": cert["cutoff"],
                         "shots": shots, "mu": str(MU),
                         "certified_better_than_raw_through_interval": worst < raw_lower},
                        {"raw_MSE": raw, "exact_calibration_MSE": exact_risk,
                         "partial_calibration_MSE": risk,
                         "interval_worst_calibrated_MSE": worst,
                         "interval_best_possible_raw_MSE": raw_lower}))
    walsh_time = perf_counter()-walsh_start
    examples = {str(k): next(s for s, trace in enumerate(decoder.traces) if len(trace) == k)
                for k in (2, 4, 8)}
    payload = {
        "scope": "Exact finite PATH25 extension with independent Bernoulli data/syndrome noise; exponential in 12 checks; not a KP implementation or a circuit model.",
        "source": {"manuscript_pages": [3, 4, 5, 19, 38],
                   "sections": ["2", "7.3", "Appendix F"],
                   "seed_row_masks": SEED, "seed_columns": SEED_COLUMNS},
        "code": {"n": n, "m": decoder.m, "HX": hx, "HZ": hz,
                 "rank_HX": 12, "rank_HZ": 12, "logical_qubits": 1,
                 "logical_X_witness": witness_x,
                 "logical_Z_representatives": masks,
                 "representatives_same_logical_class": True},
        "decoder": {"candidate_count": len(decoder.candidates),
                    "family": "All nonempty generator subsets with nonempty footprint; NO regular FGL filter",
                    "candidate_masks_in_order": decoder.candidates,
                    "beta": F(1, 2), "score_denominator": "|HX F|",
                    "tie_order": "(|F|, numerical mask(F)) ascending",
                    "syndromes": 4096, "independent_exact_score_comparators_agree": True,
                    "steps_histogram": action_hist,
                    "maximum_accepted_actions": max(action_hist),
                    "syndromes_with_at_least_two_actions":
                        sum(count for steps, count in action_hist.items() if steps >= 2),
                    "syndromes_terminating_with_nonzero_syndrome":
                        sum(s != 0 for s in decoder.terminals),
                    "correction_table_sha256": correction_hash,
                    "example_syndromes_by_trace_length": examples,
                    "representative_correction_nonlinearity": nonlinear},
        "host": host_stats,
        "catalogue": {**catalogue_stats,
                      "integer_spectra": [{"data_weight": i, "check_weight": j, **values}
                                          for (i, j), values in sorted(spectra.items())]},
        "encoded_state": {
            "formula": "(2|0_L>+|1_L>)/sqrt(5)",
            "logical_zero": "uniform positive superposition over S_X (4096 basis states)",
            "logical_one": "X^15 applied to logical_zero",
            "mu": MU, "coset_membership_and_protected_character_verified": True,
            "identity": "For each residual R, <Z^u>_R = (-1)^(u.R)*mu",
            "final_measurement": "Ideal physical Z readout; all queried masks and physical checks commute"},
        "walsh": {
            "alpha": "1-2p (not odds)", "gamma": "1-2q (not odds)",
            "G_u": "2^-12 sum_a (-1)^(a.t) alpha^wt(u+HX^T a)",
            "unfiltered": "sum_s (-1)^(u.C(s)) 2^-12 sum_a (-1)^(a.s) alpha^wt(u+HX^T a) gamma^wt(a)",
            "filtered_numerator": "sum_s (-1)^(u.C(s)) Pr[D=s+HX C(s)] G_u(HX C(s))",
            "P0": "same filtered sum with u=0",
            "arithmetic": "Integer FWT with common denominators; final fractions exact",
            "syndrome_tables_size": 4096,
            "cost_limitation": "Theta(m*2^m) transform arithmetic plus full decoder table; no claim of polynomial scaling in m",
            "control_closed_form": "lambda_4369=(1-2p)^4*(1-2q)^4"},
        "five_qubit_independent_validation": five_qubit_validation,
        "evaluations": evaluations,
        "measured_single_run_seconds": {"decoder_and_algebra": decoder_time,
                                        "low_weight_catalogue_and_recomposition": catalogue_time,
                                        "walsh_certificates_and_MSE": walsh_time,
                                        "total": perf_counter()-started},
        "not_reproduced": [
            "Manuscript's 12438 first-exit support queries",
            "Manuscript's selected source catalogue of 565 histories",
            "Uniform partition-access/KP algorithm or finite-region enlargement"],
    }
    (args.out/"path25_results.json").write_text(
        json.dumps(serialize(payload), indent=2, sort_keys=True)+"\n", encoding="utf-8")
    write_csv(args.out/"path25_metrics.csv", metrics_rows)
    write_csv(args.out/"path25_certificates.csv", certificate_rows)
    write_csv(args.out/"path25_mse.csv", mse_rows)
    write_csv(args.out/"path25_decoder_table.csv", [
        {"syndrome": s, "initial_weight": s.bit_count(), "correction": decoder.corrections[s],
         "terminal_syndrome": decoder.terminals[s], "steps": len(decoder.traces[s]),
         "trace_masks": " ".join(map(str, decoder.traces[s]))}
        for s in range(4096)])
    print("PASS: PATH25 seed, 103 candidates, rank12+12, and exact full SSF on all4096 syndromes.")
    print("PASS: correction table matches independent implementation SHA256.")
    print("Actions:", action_hist)
    print("Host:", host_stats)
    print("Catalogue:", {k: v for k, v in catalogue_stats.items()
                          if k not in ("examples", "comparison_scope")})
    print("PASS: integer Walsh normalization, q=0 and p=0 checks, independent five-qubit direct enumeration.")
    for entry in evaluations:
        if entry["primary_example"]:
            exact = entry["exact"]
            print("p,q =", entry["p"], entry["q"], "P0 =", decimal_text(exact["P0"]))
            for u in masks:
                obs = exact["observables"][u]
                print("u =", u, "lambda =", decimal_text(obs["lambda"]),
                      "lambda_T =", decimal_text(obs["lambda_T"]))
    print("Output:", args.out.resolve())


if __name__ == "__main__":
    main()
