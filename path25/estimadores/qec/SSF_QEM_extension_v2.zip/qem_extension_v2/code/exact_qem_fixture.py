#!/usr/bin/env python3
"""Exact finite QEM calibration on the manuscript's Appendix G circuit.

Run with Python 3.10+ (standard library only):
    python exact_qem_fixture.py --out .

This reproduces the five-data-qubit code, complete FGL candidate family,
fixed decoder and four noisy categorical locations of Appendix G, together
with Appendix C's greedy CNOT schedule. It enumerates all 2048 assignments,
using fractions.Fraction throughout. The secondary phenomenological model
uses the SAME code/decoder with independent data-X and syndrome bits; that
noise model is an explicitly labelled additional illustration.

The circuit output is an X residual. Data-Z faults cannot affect the chosen
protected Z observables. An explicit pure encoded state with logical
Z expectation 3/5 establishes the state-expectation identities.

Calibration intervals are finite bounds from truncating the number of
nonbaseline physical locations. They do NOT implement a KP/cluster
truncation, prove a uniform admissible noise region, or establish scaling.
The readout is one joint (Pauli, classical flip) location, whose baseline
has mass (1-e)^2. The published 511 first-exit support queries, 67552
paths and 982704 comparisons are NOT reproduced by this script.
"""

from __future__ import annotations

import argparse
import csv
import json
from collections import Counter
from decimal import Decimal, localcontext
from fractions import Fraction as F
from itertools import product
from math import comb
from pathlib import Path


N = 5
HX = (19, 28)  # rows (1,1,0,0,1), (0,0,1,1,1); bit i = data qubit i
HZ = (21, 26)  # rows (1,0,1,0,1), (0,1,0,1,1)
A = 1
BETA = F(1, 100)
MU = F(3, 5)
PAULIS = ("I", "X", "Y", "Z")
PAULI_XZ = {"I": (0, 0), "X": (1, 0), "Y": (1, 1), "Z": (0, 1)}
PUBLIC_E = F(1, 4 * 729**7)
E_POINTS = (F(1, 100), F(3, 100), F(1, 20), F(1, 10), PUBLIC_E)
P_POINTS = (F(1, 100), F(3, 100), F(1, 20), F(1, 10))
Q_POINTS = (F(0), F(1, 100), F(3, 100), F(1, 20), F(1, 10))


def parity(mask: int) -> int:
    return mask.bit_count() & 1


def syndrome(mask: int, rows=HX) -> int:
    return sum(parity(mask & row) << j for j, row in enumerate(rows))


def span(rows) -> set[int]:
    result = {0}
    for row in rows:
        result |= {x ^ row for x in tuple(result)}
    return result


SX = span(HZ)
SZ = span(HX)
TSPACE = {r for r in range(1 << N) if syndrome(r) == 0}
PROTECTED = {u for u in range(1 << N) if syndrome(u, HZ) == 0}
LOGICAL_Z = tuple(sorted(PROTECTED - SZ))
LOGICAL_X = min(TSPACE - SX)


def make_candidates() -> tuple[int, ...]:
    candidates = set()
    for generator in HZ:
        subset = generator
        while subset:
            footprint = syndrome(subset)
            if footprint and 2 * footprint.bit_count() >= A * subset.bit_count():
                candidates.add(subset)
            subset = (subset - 1) & generator
    return tuple(sorted(candidates, key=lambda f: (-syndrome(f).bit_count(), f)))


CANDIDATES = make_candidates()


def decode(initial_syndrome: int) -> tuple[int, tuple[int, ...]]:
    """Full prescribed SSF: footprint-normalized score, fixed global order."""
    s, correction, trace = initial_syndrome, 0, []
    while True:
        scored = [
            (F(2 * (s & syndrome(f)).bit_count() - syndrome(f).bit_count(),
               syndrome(f).bit_count()), f)
            for f in CANDIDATES
        ]
        best_score = max(score for score, _ in scored)
        if best_score < BETA:
            return correction, tuple(trace)
        winner = next(f for score, f in scored if score == best_score)
        updated = s ^ syndrome(winner)
        assert updated.bit_count() < s.bit_count()
        correction ^= winner
        trace.append(winner)
        s = updated


def decode_integer_reference(initial_syndrome: int) -> tuple[int, tuple[int, ...]]:
    """Independent exact comparator: cross products, no Fraction scores."""
    s, correction, trace = initial_syndrome, 0, []
    while True:
        winner, best_num, best_den = None, None, None
        for f in CANDIDATES:
            footprint = syndrome(f)
            denominator = footprint.bit_count()
            numerator = 2 * (s & footprint).bit_count() - denominator
            if winner is None or numerator * best_den > best_num * denominator:
                winner, best_num, best_den = f, numerator, denominator
        if best_num * BETA.denominator < BETA.numerator * best_den:
            return correction, tuple(trace)
        s ^= syndrome(winner)
        correction ^= winner
        trace.append(winner)
        assert len(trace) <= len(HX)


DECODER = {s: decode(s) for s in range(1 << len(HX))}


def greedy_schedule() -> tuple[int, tuple[tuple[tuple[int, int], ...], ...]]:
    edges = [(c, v) for c, row in enumerate(HX)
             for v in range(N) if (row >> v) & 1]
    used_check, used_data = {}, {}
    colors = {}
    for c, v in edges:
        taken = used_check.get(c, set()) | used_data.get(v, set())
        color = 1
        while color in taken:
            color += 1
        colors[c, v] = color
        used_check.setdefault(c, set()).add(color)
        used_data.setdefault(v, set()).add(color)
    r = max(row.bit_count() for row in HX)
    d = max(syndrome(1 << v).bit_count() for v in range(N))
    layers = r + d - 1
    return layers, tuple(tuple(edge for edge in edges if colors[edge] == layer)
                         for layer in range(1, layers + 1))


LAYERS, SCHEDULE = greedy_schedule()


def add_pauli(x: int, z: int, wire: int, label: str) -> tuple[int, int]:
    a, b = PAULI_XZ[label]
    return x ^ (a << wire), z ^ (b << wire)


def literal_pauli_propagation(gate_control, gate_target, wait0, wait1,
                             readout_pauli, readout_flip):
    """Conjugate each Pauli through every later CNOT, including its Z part."""
    x = z = 0
    for layer in SCHEDULE:
        for c, v in layer:
            ancilla = N + c
            if (x >> v) & 1:
                x ^= 1 << ancilla
            if (z >> ancilla) & 1:
                z ^= 1 << v
            if (c, v) == (0, 4):
                x, z = add_pauli(x, z, v, gate_control)
                x, z = add_pauli(x, z, ancilla, gate_target)
    x, z = add_pauli(x, z, 0, wait0)
    x, z = add_pauli(x, z, 1, wait1)
    x, z = add_pauli(x, z, N, readout_pauli)
    data_x = x & ((1 << N) - 1)
    data_z = z & ((1 << N) - 1)
    observed = ((x >> N) & ((1 << len(HX)) - 1)) ^ readout_flip
    return data_x, data_z, observed


def response_formula(gate_control, gate_target, wait0, wait1,
                     readout_pauli, readout_flip):
    a = PAULI_XZ[gate_control][0]
    b = PAULI_XZ[gate_target][0]
    w0 = PAULI_XZ[wait0][0]
    w1 = PAULI_XZ[wait1][0]
    read = PAULI_XZ[readout_pauli][0] ^ readout_flip
    return (a << 4) ^ w0 ^ (w1 << 1), (b ^ read) ^ (a << 1)


def empty_counts():
    return {"total": 0, "P0": 0, "Psil": 0,
            "lambda": {str(u): 0 for u in LOGICAL_Z},
            "filtered_numerator": {str(u): 0 for u in LOGICAL_Z}}


def add_history(counts, residual):
    accepted = residual in TSPACE
    failed = accepted and residual not in SX
    counts["total"] += 1
    counts["P0"] += int(accepted)
    counts["Psil"] += int(failed)
    for u in LOGICAL_Z:
        sign = 1 - 2 * parity(u & residual)
        counts["lambda"][str(u)] += sign
        counts["filtered_numerator"][str(u)] += sign * accepted
    if accepted:
        # One logical qubit: all protected nontrivial representatives agree.
        signs = {1 - 2 * parity(u & residual) for u in LOGICAL_Z}
        assert signs == ({-1} if failed else {1})


def enumerate_circuit():
    spectra, location_counts, residual_counts = {}, Counter(), Counter()
    max_actions = 0
    total = 0
    for a, b, w0, w1, read, flip in product(
            PAULIS, PAULIS, PAULIS, PAULIS, PAULIS, (0, 1)):
        ex, ez, observed = literal_pauli_propagation(a, b, w0, w1, read, flip)
        assert (ex, observed) == response_formula(a, b, w0, w1, read, flip)
        correction, trace = DECODER[observed]
        assert (correction, trace) == decode_integer_reference(observed)
        residual = ex ^ correction
        assert syndrome(residual) == observed ^ syndrome(ex)
        key = (int((a, b) != ("I", "I")), int(w0 != "I"),
               int(w1 != "I"), int(read != "I"), flip)
        active_locations = key[0] + key[1] + key[2] + int(key[3] or key[4])
        counts = spectra.setdefault(key, empty_counts())
        add_history(counts, residual)
        location_counts[active_locations] += 1
        residual_counts[residual] += 1
        max_actions = max(max_actions, len(trace))
        total += 1
    assert total == 2048
    assert dict(location_counts) == {0: 1, 1: 28, 2: 246, 3: 828, 4: 945}
    assert max_actions == 1
    return spectra, {"assignments": total,
                     "counts_by_nonbaseline_locations": dict(sorted(location_counts.items())),
                     "counts_by_residual_mask": dict(sorted(residual_counts.items())),
                     "max_accepted_actions": max_actions,
                     "literal_propagation_equals_linear_response": True,
                     "fraction_and_integer_decoders_agree": True,
                     "first_exit_oracle_reproduced": False}


def enumerate_phenomenological():
    spectra = {}
    for e, d in product(range(1 << N), range(1 << len(HX))):
        observed = syndrome(e) ^ d
        correction, trace = DECODER[observed]
        residual = e ^ correction
        assert syndrome(residual) == d
        key = (e.bit_count(), d.bit_count())
        add_history(spectra.setdefault(key, empty_counts()), residual)
    for (i, j), counts in spectra.items():
        assert counts["total"] == comb(N, i) * comb(len(HX), j)
    return spectra


def circuit_weight(key, e):
    gate, wait0, wait1, read, flip = key
    paulis = wait0 + wait1 + read
    degree = gate + paulis + flip
    return e**degree * (1 - e)**(5 - degree) / (15**gate * 3**paulis)


def phenomenological_weight(key, p, q):
    i, j = key
    return p**i * (1-p)**(N-i) * q**j * (1-q)**(len(HX)-j)


def evaluate(spectra, weight_function):
    result = {"total": F(0), "P0": F(0), "Psil": F(0),
              "lambda": {str(u): F(0) for u in LOGICAL_Z},
              "filtered_numerator": {str(u): F(0) for u in LOGICAL_Z}}
    for key, counts in spectra.items():
        weight = weight_function(key)
        for name in ("total", "P0", "Psil"):
            result[name] += counts[name] * weight
        for name in ("lambda", "filtered_numerator"):
            for u in LOGICAL_Z:
                result[name][str(u)] += counts[name][str(u)] * weight
    assert result["total"] == 1
    result["Qsil"] = result["Psil"] / result["P0"]
    result["lambda_T"] = {str(u): result["filtered_numerator"][str(u)] / result["P0"]
                          for u in LOGICAL_Z}
    assert set(result["lambda_T"].values()) == {1 - 2 * result["Qsil"]}
    return result


def verify_circuit_formulas(e, result):
    theta = 2 * e / 3
    z = 1 - 2 * theta
    g = 1 - 16 * e / 15
    h = z * (1 - 2 * e)
    assert result["P0"] == (1 + z*z*g*h) / 2
    assert result["Psil"] == theta * (1 - z*g*h) / 2
    for u in LOGICAL_Z:
        assert result["lambda"][str(u)] == (z*g*h if u in (5, 25) else z)
        assert result["filtered_numerator"][str(u)] == z * (1 + g*h) / 2
        assert result["lambda_T"][str(u)] == z * (1 + g*h) / (1 + z*z*g*h)


def verify_phenomenological_formulas(p, q, result):
    z, t = 1 - 2*p, 1 - 2*q
    assert result["P0"] == (1-q)**2
    assert result["Psil"] == (1-q)**2 * 2*p*(1-p)
    assert result["Qsil"] == 2*p*(1-p)
    for u in LOGICAL_Z:
        power = {5: 2, 10: 0, 22: 1, 25: 1}[u]
        assert result["lambda"][str(u)] == z*z*t**power
        assert result["lambda_T"][str(u)] == z*z


def verify_encoded_state():
    """Positive amplitudes sqrt(probabilities) define an explicit pure state."""
    probs = {s: F(1, 5) for s in SX}
    probs.update({s ^ LOGICAL_X: F(1, 20) for s in SX})
    assert sum(probs.values()) == 1
    assert all(x in TSPACE for x in probs)
    for stabilizer in SX:
        assert all(probs[x ^ stabilizer] == weight for x, weight in probs.items())
    for u in LOGICAL_Z:
        ideal = sum(weight * (1 - 2 * parity(u & x))
                    for x, weight in probs.items())
        assert ideal == MU
        for residual in range(1 << N):
            actual = sum(weight * (1 - 2 * parity(u & (x ^ residual)))
                         for x, weight in probs.items())
            assert actual == MU * (1 - 2 * parity(u & residual))
    return {"logical_X_mask": LOGICAL_X,
            "logical_zero_basis_masks": sorted(SX),
            "logical_one_basis_masks": sorted(s ^ LOGICAL_X for s in SX),
            "pure_state": "(2|0_L> + |1_L>)/sqrt(5)",
            "logical_basis": "|0_L>=sum_{s in S_X}|s>/2; |1_L>=X^L|0_L>",
            "basis_probabilities": {str(x): str(p) for x, p in sorted(probs.items())},
            "mu": str(MU),
            "stabilizer_membership_verified": True,
            "state_expectation_identity_verified_for_all_32_residuals": True}


def qtext(x):
    return str(x)


def decimal_text(x, digits=24):
    with localcontext() as ctx:
        ctx.prec = digits
        return str(Decimal(x.numerator) / Decimal(x.denominator))


def serial_result(result):
    return {name: ({key: qtext(value) for key, value in values.items()}
                   if isinstance(values, dict) else qtext(values))
            for name, values in result.items()}


def circuit_spectrum_rows(spectra):
    rows = []
    for key, counts in sorted(spectra.items()):
        gate, wait0, wait1, read, flip = key
        rows.append({"gate_nonidentity": gate, "wait0_nonidentity": wait0,
                     "wait1_nonidentity": wait1, "readout_pauli_nonidentity": read,
                     "readout_classical_flip": flip,
                     "nonbaseline_locations": gate + wait0 + wait1 + int(read or flip),
                     "e_degree": sum(key),
                     "category_denominator": 15**gate * 3**(wait0+wait1+read),
                     **counts})
    return rows


def calibration_rows(spectra, evaluations):
    output = []
    for e, exact in evaluations:
        for cutoff in range(5):
            retained = {key: counts for key, counts in spectra.items()
                        if key[0]+key[1]+key[2]+int(key[3] or key[4]) <= cutoff}
            retained_count = sum(counts["total"] for counts in retained.values())
            mass = sum(counts["total"] * circuit_weight(key, e)
                       for key, counts in retained.items())
            tail = 1 - mass
            # Independent tail from 3 Bernoulli(e) physical locations plus
            # one joint readout with nonbaseline probability 2e-e^2.
            read_error = 2*e-e*e
            independent_mass = sum(
                F(comb(3, j)) * e**j * (1-e)**(3-j)
                * read_error**b * (1-read_error)**(1-b)
                for j in range(4) for b in (0, 1) if j+b <= cutoff)
            assert mass == independent_mass
            for u in LOGICAL_Z:
                signed = sum(counts["lambda"][str(u)] * circuit_weight(key, e)
                             for key, counts in retained.items())
                low, high = max(F(-1), signed-tail), min(F(1), signed+tail)
                midpoint = (low+high) / 2
                lam = exact["lambda"][str(u)]
                assert low <= lam <= high
                filtered_signed = sum(
                    counts["filtered_numerator"][str(u)] * circuit_weight(key, e)
                    for key, counts in retained.items())
                # This auxiliary conditional interval uses the exact P0,
                # independently verified by Appendix G's closed formula.
                low_t = max(F(-1), (filtered_signed-tail)/exact["P0"])
                high_t = min(F(1), (filtered_signed+tail)/exact["P0"])
                assert low_t <= exact["lambda_T"][str(u)] <= high_t
                row = {"model": "original_appendix_G_circuit",
                       "e": qtext(e), "e_decimal": decimal_text(e),
                       "u_mask": u, "u_support": " ".join(str(v) for v in range(N)
                                                       if (u >> v) & 1),
                       "cutoff_nonbaseline_locations": cutoff,
                       "retained_assignments": retained_count,
                       "total_assignments": 2048,
                       "mu": qtext(MU)}
                values = {"lambda_exact": lam, "signed_retained_sum": signed,
                          "retained_probability": mass, "tail": tail,
                          "lambda_lower": low, "lambda_upper": high,
                          "lambda_midpoint": midpoint, "P0": exact["P0"],
                          "lambda_T_exact": exact["lambda_T"][str(u)],
                          "filtered_signed_retained_sum": filtered_signed,
                          "lambda_T_lower_using_exact_P0": low_t,
                          "lambda_T_upper_using_exact_P0": high_t}
                for key, value in values.items():
                    row[key] = qtext(value)
                    row[key+"_decimal"] = decimal_text(value)
                output.append(row)
    return output


def metrics_rows(circuit_evaluations, phen_evaluations):
    rows = []
    for model, parameters, exact in [
        *[("original_appendix_G_circuit", {"e": qtext(e), "p": "", "q": ""}, result)
          for e, result in circuit_evaluations],
        *[("additional_phenomenological_model",
           {"e": "", "p": qtext(p), "q": qtext(q)}, result)
          for p, q, result in phen_evaluations]]:
        for u in LOGICAL_Z:
            row = {"model": model, **parameters, "u_mask": u, "mu": qtext(MU)}
            lam, lam_t = exact["lambda"][str(u)], exact["lambda_T"][str(u)]
            numerator = exact["filtered_numerator"][str(u)]
            values = {"lambda": lam, "P0": exact["P0"], "Psil": exact["Psil"],
                      "Qsil": exact["Qsil"], "filtered_numerator": numerator,
                      "lambda_T": lam_t, "observed_mean": MU*lam,
                      "accepted_conditional_mean": MU*lam_t,
                      # Per total physical shot, I_T*O / numerator is unbiased.
                      "unfiltered_exact_mitigation_variance_per_shot": 1/(lam*lam)-MU*MU,
                      "filtered_exact_mitigation_variance_per_total_shot":
                          exact["P0"]/(numerator*numerator)-MU*MU}
            for name, value in values.items():
                row[name] = qtext(value)
                row[name+"_decimal"] = decimal_text(value)
            rows.append(row)
    return rows


def write_csv(path, rows):
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    assert all(syndrome(row) == 0 for row in HZ)
    assert len(SX) == len(SZ) == 4 and len(TSPACE) == len(PROTECTED) == 8
    assert LOGICAL_Z == (5, 10, 22, 25) and LOGICAL_X == 3
    assert len(CANDIDATES) == 11
    assert [DECODER[s][0] for s in range(4)] == [0, 1, 4, 5]
    assert all(DECODER[s] == decode_integer_reference(s) for s in range(4))
    assert LAYERS == 4
    assert (LAYERS+2)*(N+len(HX))-sum(row.bit_count() for row in HX) == 36
    state = verify_encoded_state()
    circuit_spectra, circuit_checks = enumerate_circuit()
    phen_spectra = enumerate_phenomenological()
    circuit_evaluations, phen_evaluations = [], []
    for e in E_POINTS:
        exact = evaluate(circuit_spectra, lambda key: circuit_weight(key, e))
        verify_circuit_formulas(e, exact)
        circuit_evaluations.append((e, exact))
    for p, q in product(P_POINTS, Q_POINTS):
        exact = evaluate(phen_spectra, lambda key: phenomenological_weight(key, p, q))
        verify_phenomenological_formulas(p, q, exact)
        phen_evaluations.append((p, q, exact))
    published = next(result for e, result in circuit_evaluations if e == PUBLIC_E)
    with localcontext() as ctx:
        ctx.prec = 40
        expected_rounded = Decimal("9.9765540175e-42")
        actual = Decimal(published["Psil"].numerator) / Decimal(published["Psil"].denominator)
        assert abs(actual / expected_rounded - 1) < Decimal("1e-11")
    payload = {
        "scope": "Exact finite enumeration; no claim of a uniform KP region or scaling.",
        "source": {"manuscript": "Exact canonical recomposition and silent-failure estimation for small-set-flip decoding",
                   "sections": ["2.1-2.2", "4.1 Eq. (11)", "7.4", "C.1", "G"],
                   "pages": [3, 4, 11, 19, 28, 29, 39]},
        "bit_convention": "bit i denotes data qubit i; matrices listed as integer row masks",
        "code": {"n": N, "HX": HX, "HZ": HZ, "SX": sorted(SX), "SZ": sorted(SZ),
                 "T": sorted(TSPACE), "protected_masks": sorted(PROTECTED),
                 "logical_Z_representatives": LOGICAL_Z, "encoded_logical_qubits": 1},
        "decoder": {"A": A, "beta": qtext(BETA),
                    "filter": "F subset of an HZ generator, phi=HX F nonzero, 2|phi|>=A|F|",
                    "score": "(2|s intersect phi|-|phi|)/|phi|",
                    "order": "ascending (-|phi|, numerical_mask)",
                    "candidate_masks_in_order": CANDIDATES,
                    "corrections_by_syndrome": {str(s): c for s, (c, _) in DECODER.items()},
                    "traces_by_syndrome": {str(s): trace for s, (_, trace) in DECODER.items()}},
        "circuit": {"layers": LAYERS, "CNOT_layers_check_data_pairs": SCHEDULE,
                    "locations": 36, "noisy_locations": 4,
                    "alphabet_sizes": [16, 4, 4, 8], "host_vertices": 41,
                    "readout_baseline_probability": "(1-e)^2",
                    "noise": "Depolarizing total rate e at CNOT(4,check0), final waits 0,1 and readout Pauli at check0; independent classical flip e at that same readout; all other locations ideal",
                    **circuit_checks},
        "encoded_state": state,
        "spectra": {
            "circuit_weight": "e^e_degree*(1-e)^(5-e_degree)/category_denominator",
            "circuit": circuit_spectrum_rows(circuit_spectra),
            "phenomenological_weight": "p^data_weight*(1-p)^(5-data_weight)*q^syndrome_weight*(1-q)^(2-syndrome_weight)",
            "phenomenological": [{"data_weight": i, "syndrome_weight": j, **counts}
                                 for (i, j), counts in sorted(phen_spectra.items())]},
        "circuit_evaluations": [{"e": qtext(e), "published_checksum_point": e == PUBLIC_E,
                                 **serial_result(result)}
                                for e, result in circuit_evaluations],
        "phenomenological_evaluations": [
            {"p": qtext(p), "q": qtext(q), **serial_result(result)}
            for p, q, result in phen_evaluations],
        "formulas_verified": {
            "circuit_definitions": "z=1-4e/3; g=1-16e/15; h=z*(1-2e)",
            "circuit": {"lambda_5_and_25": "z*g*h", "lambda_10_and_22": "z",
                        "P0": "(1+z^2*g*h)/2", "Psil": "(2e/3)*(1-z*g*h)/2",
                        "lambda_T_all_logical_representatives":
                            "z*(1+g*h)/(1+z^2*g*h)"},
            "phenomenological_definitions": "z=1-2p; t=1-2q",
            "phenomenological": {"lambda_5": "z^2*t^2", "lambda_10": "z^2",
                                "lambda_22_and_25": "z^2*t", "P0": "(1-q)^2",
                                "Qsil": "2p*(1-p)", "lambda_T": "z^2"}},
        "calibration_certificate": {
            "method": "Retain histories with at most k nonbaseline physical locations",
            "tail": "1 - retained probability; computed independently from the four baseline masses",
            "interval": "[signed_retained_sum-tail, signed_retained_sum+tail] intersect [-1,1]",
            "readout_count": "The joint category (P,b) is one nonbaseline location iff P!=I or b!=0",
            "conditional_intervals": "The auxiliary lambda_T intervals use exact P0 from the verified Appendix G formula",
            "not_claimed": "No KP algorithm, first-exit enumeration, uniform rate region, scaling, or unknown-calibration sampling cost"},
        "expectation_and_MSE": {
            "mu": qtext(MU), "ideal_final_Z_measurement_assumption": True,
            "unfiltered_mean": "E[O]=lambda*mu",
            "conditional_mean": "E[O|T]=lambda_T*mu",
            "physical_budget": "M independent complete noisy experiments including rejected histories",
            "raw_MSE": "(lambda-1)^2*mu^2 + (1-lambda^2*mu^2)/M",
            "exact_mitigated_MSE": "(1/lambda^2-mu^2)/M",
            "point_calibration_MSE": "(lambda/lambda_hat-1)^2*mu^2 + (1-lambda^2*mu^2)/(M*lambda_hat^2)",
            "zero_weighted_filtered_estimator": "mean(I_T*O)/(P0*lambda_T)",
            "zero_weighted_filtered_MSE": "(1/(P0*lambda_T^2)-mu^2)/M",
            "shot_variance_excludes": "Classical enumeration cost; calibration is deterministic in this finite example"}
    }
    (args.out / "exact_results.json").write_text(
        json.dumps(payload, indent=2, sort_keys=True)+"\n", encoding="utf-8")
    write_csv(args.out / "exact_metrics.csv", metrics_rows(circuit_evaluations, phen_evaluations))
    calibration = calibration_rows(circuit_spectra, circuit_evaluations)
    write_csv(args.out / "finite_calibration.csv", calibration)
    print("PASS: CSS membership, all four syndrome decodings, 11 FGL candidates.")
    print("PASS: all 2048 original circuit assignments, literal Pauli propagation, closed formulas.")
    print("PASS: all 128 additional Bernoulli histories and all representative formulas.")
    print("PASS: realizable encoded-state expectation identities and all finite calibration intervals.")
    print("Published e =", PUBLIC_E, "; Psil =", decimal_text(published["Psil"]))
    print("Output:", args.out.resolve())
    for e, result in circuit_evaluations:
        if e == PUBLIC_E:
            continue
        print("e =", e, "lambda_5 =", decimal_text(result["lambda"]["5"]),
              "lambda_10 =", decimal_text(result["lambda"]["10"]),
              "lambda_T =", decimal_text(result["lambda_T"]["5"]),
              "P0 =", decimal_text(result["P0"]))


if __name__ == "__main__":
    main()
