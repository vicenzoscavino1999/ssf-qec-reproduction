#!/usr/bin/env python3
"""Reproduce the exact QEM extension calculations from this package."""
from pathlib import Path
import argparse
import csv
import json
from fractions import Fraction
import subprocess
import sys


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plots',action='store_true',help='also regenerate PNG/SVG with matplotlib')
    args=parser.parse_args()
    root=Path(__file__).resolve().parent
    commands=[
        [sys.executable,str(root/'code/exact_qem_fixture.py'),'--out',str(root/'results')],
        [sys.executable,str(root/'code/finite_observable_certificate.py'),'--e','1/20','--cutoff','2'],
        [sys.executable,str(root/'code/analyze_qem.py')]+(['--plots'] if args.plots else []),
        [sys.executable,str(root/'code/certified_mse_ranges.py')],
        [sys.executable,str(root/'code/path25_exact_qem.py'),'--out',str(root/'results/path25')],
        [sys.executable,str(root/'code/path25_exact_qem.py'),'--certificate-only','--cutoff','2',
         '--out',str(root/'results/path25')]
    ]
    for command in commands:
        subprocess.run(command,cwd=root,check=True)
    partial=json.loads((root/'results/partial_certificate.json').read_text())
    with (root/'results/finite_calibration.csv').open() as stream:
        full=list(csv.DictReader(stream))
    for u,values in partial['logical_observables'].items():
        reference=next(r for r in full if r['e']==partial['e']
            and r['u_mask']==u and int(r['cutoff_nonbaseline_locations'])==partial['cutoff_nonbaseline_locations'])
        for key in ['signed_retained_sum','lambda_lower','lambda_upper','lambda_midpoint']:
            assert Fraction(values[key])==Fraction(reference[key]),(u,key)
        for key in ['retained_probability','tail']:
            assert Fraction(partial[key])==Fraction(reference[key]),key
    print('PASS: direct partial producer agrees with exhaustive reference for all four representatives.')
    p25=root/'results/path25'
    with (p25/'path25_partial_certificate.csv').open() as stream:
        partial_rows=list(csv.DictReader(stream))
    with (p25/'path25_certificates.csv').open() as stream:
        reference_rows=list(csv.DictReader(stream))
    for part in partial_rows:
        ref=next(row for row in reference_rows if all(row[k]==part[k]
            for k in ['p','q','u_mask','cutoff']))
        for key in ['retained_mass','tail','signed_retained_sum','lambda_lower',
                    'lambda_upper','lambda_midpoint','filtered_signed_retained_sum',
                    'lambda_T_lower','lambda_T_upper']:
            assert Fraction(part[key])==Fraction(ref[key]),(part['u_mask'],key)
    payload=json.loads((p25/'path25_partial_certificate.json').read_text())
    assert payload['decoder_syndromes_prepared']==4096
    assert payload['direct_source_histories_generated']==704
    assert payload['source_histories_above_cutoff_generated']==0
    assert payload['walsh_reference_executed'] is False
    assert payload['exact_reference_values_or_files_used'] is False
    point=next(r for r in payload['results'] if r['p']=='1/50' and r['q']=='1/100')
    risk=point['MSE_comparison_using_interval_only']['135447']
    assert Fraction(risk['best_raw_MSE'])/Fraction(risk['worst_calibrated_MSE'])>Fraction(15,2)
    print('PASS: all six PATH25 partial certificates agree exactly with the separate reference.')
    print('PASS: PATH25 interval alone certifies a risk reduction by more than 7.5 at the stated input and budget.')
    print('All exact calculations and certificates reproduced successfully.')


if __name__=='__main__':
    main()
