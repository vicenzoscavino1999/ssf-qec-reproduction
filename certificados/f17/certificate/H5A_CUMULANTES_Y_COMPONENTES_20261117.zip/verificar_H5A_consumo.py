"""Verifica las dos esquinas de H5A_consumo_y_alcance.txt con aritmética racional.

Python 3.10 o posterior. Mantener junto a verificar_H5A_interacciones.py.
Ejecutar: python verificar_H5A_consumo.py
"""
from fractions import Fraction as F
from functools import cache
from math import ceil, factorial, floor, lcm
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from verificar_H5A_interacciones import (
    DUAL_ACCIONES, cotas_locales, escalar, exigir, exp_arriba, geometria,
    limite_dual, perfil,
)


ALFA = F(633, 50)
Q = F('2e-11')
XI = F('5.55e-11')
LIBRE_V = F('2e-37')
LIBRE_C = F('5.81e-11')


@cache
def carga_grupo(e):
    """Máximo racional del perfil de episodios iniciales de un grupo."""
    exigir(e >= 1, 'tamaño del grupo')
    escala = lcm(*(v.denominator for v in DUAL_ACCIONES.values()))
    niveles = sorted((u for u in DUAL_ACCIONES if u is not None), reverse=True)
    filas = [(ceil(9*(1+u))-1, ceil(F(17,2)*(1+u)), int(escala*DUAL_ACCIONES[u]))
             for u in niveles]

    @cache
    def sufijo(nivel, k, saldo):
        if nivel == len(filas):
            return 0
        tope, minimo, peso = filas[nivel]
        mejor = 0
        for nuevo_k in range(min(k,tope)+1):
            consumo = max(minimo,ceil(F(17*k,18))) if nuevo_k < k else 0
            nuevo_saldo = min(e*nuevo_k,max(0,saldo-consumo))
            mejor = max(mejor,peso*nuevo_saldo+sufijo(nivel+1,nuevo_k,nuevo_saldo))
        return mejor

    inicial = int(escala*DUAL_ACCIONES[None])
    return F(max(inicial*e*k+sufijo(0,k,e*k) for k in range(19)), escala)


def comprobar_descuento(t, s, rho):
    exigir(DUAL_ACCIONES[None] == F(1,17), 'pago de las acciones perfectas')
    exigir(limite_dual(DUAL_ACCIONES) <= ALFA, 'cota para cualquier tamaño')
    exigir(0 < t < 1 < s and 0 < rho < 1, 'parámetros de la inclinación')
    costes = []
    for e in range(1, 17):
        coste = carga_grupo(e)
        costes.append(coste)
        ahorro = ALFA*e-coste
        exigir(ahorro >= 0, 'descuento por grupo')
        # Redondear el exponente hacia abajo da un mayorante porque t<1.
        mil = floor(1000*ahorro)
        exigir(t**mil <= (rho*s**e)**1000, f'descuento uniforme, e={e}')
    exigir(rho*s**17 >= 1, 'todos los tamaños desde 17, por monotonía')
    exigir(costes[:3] == [F(9), F(324,17), F(33)], 'primeros valores del perfil')
    return costes


def parametros(sin_cuatro):
    if sin_cuatro:
        p, t, s, x, rho = map(F, ('4e-38','0.0057','2.7','2.88e-9','4.645e-8'))
        S = ('1.77515e-20','1.85263e-20','4.74776e-24','4.90137e-19','4.67072e-19','4.67267e-18')
        P = ('1.89811e-12','1.78509e-12','1.81843e-11')
        C = ('2.71584e-24','2.74025e-24','4.66320e-22')
        U = ('1.70715e-8','1.78166e-8','5.89410e-11')
    else:
        p, t, s, x, rho = map(F, ('3.4e-38','0.00567','3','2.615e-9','7.747e-9'))
        S = ('8.78289e-20','9.18545e-20','2.70328e-23','2.24859e-18','2.14278e-18','2.14508e-17')
        P = ('5.91081e-12','5.59910e-12','6.31604e-11')
        C = ('3.20812e-23','3.23697e-23','5.51271e-21')
        U = ('1.78880e-8','1.87079e-8','5.90802e-11')
    return p, t, s, x, rho, *(list(map(F, v)) for v in (S,P,C,U))


def verificar(sin_cuatro, superior=exp_arriba):
    p, t, s, x, rho, S, P, C, U = parametros(sin_cuatro)
    costes = comprobar_descuento(t, s, rho)
    base, v2, c2 = geometria()
    k, pares_vv, pares_vc, pares_cv = cotas_locales(sin_cuatro)
    orden = (0,1,3,0,1,2)
    M = [[base[i][j] for j in orden] for i in orden]
    N = [row[:3] for row in M[:3]]
    N[2][2] = 0
    mv = max(sum(row[:2]) for row in base[:2])
    mc = max(row[3] for row in base[:2])
    cv, cc = sum(base[3][:2]), base[3][3]
    f = (17,18,1,17,18,306)
    lectores = (18,17,1,18,17,306)
    alineados = v2+c2-1
    lam = t*(F(alineados,4)+(v2*c2-alineados)*t/17)
    exigir(0 < lam < 1 and t/4 < F(1,17), 'cadenas causales')
    J = [[ancho*n/(1-lam) for n in lectores] for ancho in f]
    V, D = max(U[:2]), U[2]
    nv, ng = 18*v2+17*c2, 18*306
    h = nv*V+306*D
    Bv = pares_vv*V+pares_vc*D+ng*h**(k-1)/factorial(k-1)
    Bc = pares_cv*V+cv*V*Bv+306*nv*V*h**(k-2)/factorial(k-2)
    holguras = []

    def comparar(lhs, rhs, nombre):
        exigir(lhs > rhs > 0, nombre)
        holguras.append(lhs/rhs-1)

    for i, ancho in enumerate(f):
        L, W = escalar(J[i][3:],P), escalar(M[i],S)
        Z = L+W
        if i < 3:
            precio = s*x if i < 2 else XI
            comparar(U[i], precio*superior(Z+escalar(N[i],U)), f'miembro de grupo {i}')
            comparar(S[i], rho*U[i]*(Bv if i < 2 else Bc), f'grupo completo {i}')
            continue
        j = i-3
        b = (F(1,9), F(1,10), F(1,17))[j]
        bp = (F(1,7), F(1,8), F(1,15))[j]
        extra = F(1,4)-b if j == 2 else F(0)
        G, H = superior(Z), superior(W)
        causas = escalar(J[i], S[:3]+C)
        sat = ancho*XI
        exigir(sat < F(1,2), 'medidas adscritas')
        marcada = bp*(superior(sat)-1)*G
        origen = t*sat**3*G
        comparar(P[j], t*(b*(G-1-L)+marcada+extra*L*(H-1)), f'entrada desde causa {i}')
        comparar(C[j], origen+t*causas*(b*(G-1)+marcada+extra*(H-1)), f'entrada desde hijo {i}')
        comparar(S[i], origen+t*causas*(b*G+marcada+extra*L*H), f'raíz o puente {i}')

    v0 = max(S[0]+S[3]+17*S[5], S[1]+S[4]+18*S[5])
    c0 = S[2]+35*v0
    zp, zq = p/(1-p), Q/(1-Q)
    incl = F('1.01')
    comparar(LIBRE_V, zp*superior(incl+mv*(LIBRE_V+v0)+mc*(LIBRE_C+c0)), 'dato exterior')
    comparar(LIBRE_C, zq*superior(incl+cv*(LIBRE_V+v0)+cc*(LIBRE_C+c0)), 'medida exterior')
    rv, rc = v0+18*LIBRE_V, c0+LIBRE_C
    ke, kd = 135*(mv*rv+mc*rc), cv*rv+cc*rc
    exigir(0 < rv < 1 and 0 < rc < 1 and 0 < ke < 1 and 0 < kd < 1, 'KP y anclas')
    comparar(XI, zq*superior(incl+cv*LIBRE_V+cc*LIBRE_C), 'precio de medida')
    comparar(F('2.79'), superior(incl+135*(mv*LIBRE_V+mc*LIBRE_C)), 'inclinación de dato')
    exigir((F('2.79')*zp)**50 < x**50*t**633, 'precio físico del dato')
    return p, lam, ke, kd, rv, rc, min(holguras), costes


def alcance():
    # Identidades locales de la prueba ponderada. La inferencia para
    # distancias y tamaños arbitrarios se hace por inducción en la nota.
    for u in (F(1,100), F(1,2), F(15,17)):
        razon = (1+u)/(1-u)
        minimo = ceil(17*(1+u)/2)
        for a in range(17,307):
            for h in range((a+1)//2,a+1):
                if 2*h-a >= u*a:
                    exigir(h >= minimo and h >= razon*(a-h), 'transporte por acción')
        if u == F(15,17):
            exigir(minimo*razon == 256, 'umbral a dos pasos')
    r_beta = F(101,99)
    _, v2, c2 = geometria()
    exigir(r_beta**566 < v2*c2 <= r_beta**567, 'exponente polinómico del reanclaje')
    objetivo = F('1e-6')
    z = objetivo/(1-objetivo)
    exigir(2*z/(1+2*z) == 2*objetivo/(1+objetivo), 'cambio auxiliar sólo en datos')
    # Subserie de fuentes conexas por los pares de contacto, de cualquier tamaño.
    # Se guarda una inclinación adicional de 0.05 para su cola.
    _, vv, vc, cv = cotas_locales(False)
    tv, tc = F('8e-6'), F('6e-11')
    exigir(2*z*exp_arriba(F('1.06')+vv*tv+vc*tc) < tv, 'raíz dato, subserie a 1e-6')
    exigir(Q/(1-Q)*exp_arriba(F('1.06')+cv*tv) < tc, 'raíz medida, subserie a 1e-6')


if __name__ == '__main__':
    _, firmas, _ = perfil()
    alcance()
    print(f'Perfil heredado verificado en {firmas} firmas FGL. Transporte verificado.')
    for sin_cuatro in (False,True):
        p, lam, ke, kd, rv, rc, margen, costes = verificar(sin_cuatro)
        clase = 'sin ciclos de cuatro' if sin_cuatro else 'binaria (17,18)-regular general'
        print(f'PASS {clase}: p <= {float(p):.2g}, q <= {float(Q):.2g}.')
        print(f'Lambda = {lam}. K_E = {float(ke):.12g}, K_D = {float(kd):.12g}.')
        print(f'R_V = {float(rv):.12g}, R_C = {float(rc):.12g}. Holgura en filas de árbol y exterior >= {float(margen):.4%}.')
    print('Peores cargas racionales para grupos de 1, 2 y 3 datos:', *costes[:3])
    print('PASS cola parcial a p=1e-6 y q=2e-11 para las fuentes conexas por pares de contacto.')
