"""Contraste de los enteros geométricos, la esquina y la identidad del logaritmo."""
from fractions import Fraction as F
from itertools import product
from math import ceil, comb

import verificar_H5A_fusiones as prueba


def otra_exp(z):
    # exp(z) <= (1-z/n)^(-n), con ambos redondeos hacia arriba.
    techo = 10**52
    u = F(ceil(techo*z),techo)
    assert 0 <= u < 2048
    return F(ceil(techo*(1-u/2048)**(-2048)),techo)


def simetria_rectangulo():
    por_tamano = {}
    for x,j in product(range(19),range(18)):
        a = x*(17-j)+(18-x)*j
        if not (x+j) or 2*a < 17*(x+j):
            continue
        por_tamano[a] = por_tamano.get(a,0)+a*comb(18,x)*comb(17,j)
    for r in range(3,307):
        # Doble conteo de todos los pares (corte,celda). Los 306 rectángulos
        # por check compensan las 306 celdas del rectángulo modelo.
        n = sum(v for a,v in por_tamano.items() if a <= 18*r)
        assert n==prueba.candidatos_por_check(r) and n<=prueba.NMAX


def identidad_log():
    # Una jerarquía con dos parejas internas y un término en las cuatro variables.
    # El contraste usa potencias truncadas. La demostración de la nota es formal.
    limite = (3,2,2,2)
    cero = (0,0,0,0)
    def mul(a,b):
        res = {}
        for k,x in a.items():
            for l,y in b.items():
                v = tuple(i+j for i,j in zip(k,l))
                if all(i<=j for i,j in zip(v,limite)):
                    res[v] = res.get(v,0)+x*y
        return {v:x for v,x in res.items() if x}
    def serie(p,coef):
        potencia = {cero:1}
        salida = {}
        for n in range(sum(limite)+1):
            for k,v in potencia.items():
                salida[k] = salida.get(k,0)+coef(n)*v
            potencia = mul(potencia,p)
        return {v:x for v,x in salida.items() if x}
    def log1p(p):
        return serie(p,lambda n: F((-1)**(n+1),n) if n else F(0))
    ambos = mul({cero:1,(1,0,0,0):1,(1,1,0,0):-1},
                {cero:1,(0,0,0,1):-1,(0,0,1,1):1})
    del ambos[cero]
    completo = dict(ambos)
    clave = (1,1,1,1)
    completo[clave] = completo.get(clave,0)+2
    directo = {n:v for n,v in log1p(completo).items() if min(n)>0}
    inverso = serie(ambos,lambda n:(-1)**n)
    por_fusion = log1p(mul({clave:2},inverso))
    assert directo==por_fusion and directo[clave]==2 and len(directo)>1


if __name__=='__main__':
    simetria_rectangulo()
    identidad_log()
    prueba.esquina(otra_exp)
    prueba.meta(otra_exp)
    print('PASS doble conteo de candidatos para cada cardinalidad de cubierta.')
    print('PASS identidad formal truncada contrastada con el desarrollo directo y potencias repetidas.')
    print('PASS esquina general y ambas familias en la meta con un segundo mayorante exponencial.')
