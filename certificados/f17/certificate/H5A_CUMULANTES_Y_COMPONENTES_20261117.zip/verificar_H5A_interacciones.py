"""Certificado de H5A_interacciones_por_fuentes.txt. Python >=3.10, sin dependencias.

Ejecutar con python verificar_H5A_interacciones.py. Cada decisión usa enteros
o fracciones. Los decimales de la salida son únicamente informativos.
"""
from fractions import Fraction as F
from math import ceil, factorial


def exigir(condicion, nombre):
    if not condicion:
        raise ArithmeticError(nombre)


DUAL_ACCIONES = {
    None: F(1, 17), F(1): F(1, 17), F(8, 9): F(19, 272), F(7, 9): F(19, 240),
    F(2, 3): F(19, 210), F(5, 9): F(5, 182), F(9, 17): F(1, 13),
    F(4, 9): F(1, 26), F(7, 17): F(1, 12), F(1, 3): F(7, 132),
    F(5, 17): F(1, 11), F(2, 9): F(19, 110), F(1, 9): F(1, 10),
}
DUAL_SITIOS = {
    None: F(2, 17), F(1): F(100, 153), F(8, 9): F(53, 72),
    F(7, 9): F(15301, 18360), F(2, 3): F(2188, 2295), F(5, 9): F(2186, 1989),
    F(4, 9): F(5105, 3978), F(1, 3): F(5101, 3366), F(2, 9): F(15314, 8415),
    F(1, 9): F(169, 85),
}


def limite_dual(pesos):
    exigir(all(v > 0 for v in pesos.values()), 'dual positivo')
    exigir(all(t is None or F(1, 100) < t <= 1 for t in pesos), 'niveles del perfil')
    return 18*pesos[None] + sum(v*(ceil(9*(1+t))-1) for t, v in pesos.items() if t is not None)


def coeficiente(pesos, a, d):
    c = (a-d)//2
    return pesos[None]*d + sum(v*(d if d*t.denominator < a*t.numerator else -c)
                               for t, v in pesos.items() if t is not None)


def perfil():
    # Una clave reúne sólo formas con la misma huella y descenso. Para esa
    # clave se exige el soporte máximo y el mayor recargo entre todas ellas.
    objetivos = {}
    for x in range(19):
        for j in range(18):
            m = x+j
            a = 17*x+18*j-2*x*j
            if 0 < m <= 17:
                exigir(2*a >= 17*m and a > 0, 'representante FGL de un corte')
            if m == 0 or 2*a < 17*m:
                continue
            exigir(a >= (33 if m > 1 else 17), 'huella mínima')
            for d in range(a % 2, a+1, 2):
                if 100*d < a:
                    continue
                h = (a+d)//2
                debil = False
                if m > 1 and d < a:
                    for numero, fila, columna in ((x*(17-j), 17-j, x), ((18-x)*j, j, 18-x)):
                        if numero:
                            # El check transmitido estaba apagado. El encendido
                            # en la unión de las dos líneas es la suma disjunta.
                            c_fila = max(0, ceil(F((2*fila-17)*h, a)))
                            c_col = max(0, ceil(F((2*columna-18)*h, a)))
                            debil |= c_fila+c_col < 4
                pasos, sitios = objetivos.get((a, d), (0, 0))
                objetivos[a, d] = max(pasos, 1+int(debil)), max(sitios, m)
    for (a, d), (pasos, sitios) in objetivos.items():
        exigir(coeficiente(DUAL_ACCIONES, a, d) >= pasos, f'perfil de acciones {a}, {d}')
        exigir(coeficiente(DUAL_SITIOS, a, d) >= sitios, f'perfil de sitios {a}, {d}')
    coste = limite_dual(DUAL_ACCIONES)
    sitios = limite_dual(DUAL_SITIOS)
    exigir(coste == F(3446943, 272272) < F(38, 3), 'acciones y recargos por dato')
    exigir(sitios == F(349988081, 2625480) and 1+sitios < 135, 'sitios por dato')
    return coste, len(objetivos), sum(carga == 2 for carga, _ in objetivos.values())


def exp_arriba(z):
    exigir(0 <= z < 22, 'dominio del resto de Taylor')
    total = termino = F(1)
    for k in range(1, 21):
        termino *= z/k
        total += termino
    return total + termino*z/(21*(1-z/22))


def escalar(fila, vector):
    return sum(a*b for a, b in zip(fila, vector, strict=True))


def geometria():
    A, B = 17, 18
    ram = (A-1)*(B-1)
    v2, c2 = 1+A*(B-1), 1+B*(A-1)
    v3, c3 = B*(1+ram), A*(1+ram)
    v4, c4 = 1+(v2-1)*(1+ram), 1+(c2-1)*(1+ram)
    base = [[v2*v4, c3*c3, c3*v4, v2*c3], [v3*v3, c4*c2, c4*v3, v3*c2],
            [v3*v4, c4*c3, c4*v4, v3*c3], [v2*v3, c3*c2, c3*v3, v2*c2]]
    return base, v2, c2


def cotas_locales(sin_cuatro):
    # Hasta ocho lectores, un miembro falso obligaría a elegir x>=10 e j>=9.
    # Con sólo dos fuentes, una huella cubierta tiene tamaño a lo sumo 36.
    for x in range(19):
        for j in range(18):
            m = x+j
            a = 17*x+18*j-2*x*j
            if not m or 2*a < 17*m:
                continue
            exigir(x < 10 or j < 9, 'exclusión FGL para ocho lectores')
            exigir(a > 36 or m <= 2, 'dos fuentes y huella perfecta')
    if sin_cuatro:
        exigir(18*35+18*34 <= 1242, 'pares de datos sin ciclos de cuatro')
        return 9, 1242, 18, 35
    comparten = 18*34
    singleton = comparten*18+20*17
    pura = max(17*17*18, 18*16*17)
    mixta = max((17+17*17//16)*17**2, (18+18*16//17)*18**2)
    exigir(comparten+singleton+pura+mixta <= 28200, 'pares de datos regulares')
    exigir(18+20 <= 40 and 35*(1+20) <= 800, 'pares de dato y medida')
    return 3, 28200, 40, 800


def verificar(sin_cuatro=False, superior=exp_arriba):
    base, v2, c2 = geometria()
    k, pares_vv, pares_vc, pares_cv = cotas_locales(sin_cuatro)
    indices = (0, 1, 3, 0, 1, 2)
    M = [[base[i][j] for j in indices] for i in indices]
    N = [row[:3] for row in M[:3]]
    N[2][2] = 0
    f, lectores = (17, 18, 1, 17, 18, 306), (18, 17, 1, 18, 17, 306)
    m_vv = max(sum(row[:2]) for row in base[:2]); m_vc = max(row[3] for row in base[:2])
    m_cv, m_cc = sum(base[3][:2]), base[3][3]
    lectores_datos, num_g = 18*v2+17*c2, 18*306
    exigir(lectores_datos == 10133 and num_g == 5508 and m_cv == 2766309, 'geometría de lectores')
    t, xi = F('0.0051'), F('5.55e-11')
    alineados = v2+c2-1
    lam = t*(F(alineados,4)+(v2*c2-alineados)*t/17)
    exigir(0 < lam < 1 and t/4 < F(1,17), 'tramos con y sin alineación')
    J = [[ancho*n/(1-lam) for n in lectores] for ancho in f]
    S = list(map(F, ('2.655e-17','2.655e-17','1.425e-18', '1.173e-16','1.118e-16','1.127e-15')))
    P = list(map(F, ('2.48e-10','2.357e-10','2.797e-9')))
    C = list(map(F, ('1.274e-20','1.286e-20','2.213e-18')))
    if sin_cuatro:
        p, x = F('4e-40'), F('1.19e-10')
        U = list(map(F, ('1.225e-10','1.225e-10','5.73e-11')))
    else:
        p, x = F('1e-40'), F('2.95e-11')
        U = list(map(F, ('3.024e-11','3.024e-11','5.71e-11')))
    q = F('2e-11')
    precios = (x, x, xi)
    b = (F(1,9), F(1,10), F(1,17))
    b_m = (F(1,7), F(1,8), F(1,15))
    extra = (F(0), F(0), F(1,4)-F(1,17))
    V, D = max(U[:2]), U[2]
    h = lectores_datos*V + 306*D
    Bv = pares_vv*V + pares_vc*D + num_g*h**(k-1)/factorial(k-1)
    Bc = pares_cv*V + m_cv*V*Bv + 306*lectores_datos*V*h**(k-2)/factorial(k-2)
    holguras = []

    def comparar(lhs, rhs, motivo):
        exigir(lhs > rhs > 0, motivo)
        holguras.append(lhs/rhs-1)

    for i, ancho in enumerate(f):
        L, W = escalar(J[i][3:], P), escalar(M[i], S)
        Z = L+W
        if i < 3:
            comparar(U[i], precios[i]*superior(Z+escalar(N[i],U)), f'grupo sin testigo {i}')
            comparar(S[i], U[i]*(Bv if i < 2 else Bc), f'grupo con testigo {i}')
            continue
        j = i-3
        G, H = superior(Z), superior(W)
        hijos = escalar(J[i], S[:3]+C)
        sat = ancho*xi
        exigir(sat < F(1,2), 'cola de medidas adscritas')
        marcada = b_m[j]*(superior(sat)-1)*G
        origen = t*sat**3*G
        comparar(P[j], t*(b[j]*(G-1-L) + marcada + extra[j]*L*(H-1)), f'entrada desde causa {i}')
        comparar(C[j], origen+t*hijos*(b[j]*(G-1) + marcada + extra[j]*(H-1)), f'entrada desde hijo {i}')
        comparar(S[i], origen+t*hijos*(b[j]*G + marcada + extra[j]*L*H), f'raíz o puente {i}')

    libre_v, libre_c = F('2e-39'), F('5.81e-11')
    v_nucleo = max(S[0]+S[3]+17*S[5], S[1]+S[4]+18*S[5])
    c_nucleo = S[2]+35*v_nucleo
    zp, zq = p/(1-p), q/(1-q)
    inclinacion = F('1.01')
    comparar(libre_v, zp*superior(inclinacion+m_vv*(libre_v+v_nucleo)+m_vc*(libre_c+c_nucleo)), 'datos exteriores')
    comparar(libre_c, zq*superior(inclinacion+m_cv*(libre_v+v_nucleo)+m_cc*(libre_c+c_nucleo)), 'medidas exteriores')
    rv, rc = v_nucleo+18*libre_v, c_nucleo+libre_c
    ke, kd = 135*(m_vv*rv+m_vc*rc), m_cv*rv+m_cc*rc
    exigir(0 < rv < 1 and 0 < rc < 1 and 0 < ke < 1 and 0 < kd < 1, 'presupuesto KP físico')
    comparar(xi, zq*superior(inclinacion+m_cv*libre_v+m_cc*libre_c), 'conversión de medidas')
    comparar(F('2.79'), superior(inclinacion+135*(m_vv*libre_v+m_vc*libre_c)), 'inclinación de datos')
    exigir(F(3446943,272272) < F(633,50), 'redondeo del perfil anterior')
    exigir((F('2.79')*zp)**50 < x**50*t**633, 'conversión de datos')
    exigir(p/F('1e-46') == (4000000 if sin_cuatro else 1000000) and q == F('2e-11'), 'comparación conjunta')
    exigir(F(4,578)<F('0.007') and F('0.007')**633 < (F('1e-35')*base[0][0]*F('2.7'))**50,
           'techo de esta parametrización')
    # Localización de un dato retenido a la tasa aspiracional. Las potencias
    # cuentan otras entradas distintas, condicionadas a la presencia del dato.
    objetivo = F('1e-6')
    hot = num_g*(lectores_datos*objetivo+306*q)**(k-1)/factorial(k-1)
    retencion = pares_vv*objetivo + pares_vc*q + hot
    exigir(retencion < (F('0.001243') if sin_cuatro else F('0.312')), 'retención local en el punto aspiracional')
    return p, lam, rv, rc, ke, kd, min(holguras), retencion


if __name__ == '__main__':
    presupuesto, firmas, _ = perfil()
    print(f'Perfil de acciones y recargos = {presupuesto}, con {firmas} firmas locales.')
    for sin_cuatro in (False, True):
        p, lam, rv, rc, ke, kd, margen, reten = verificar(sin_cuatro)
        clase = 'sin ciclos de cuatro' if sin_cuatro else 'binaria regular general'
        print(f'PASS {clase}. p <= {float(p):.0e}, q <= 2e-11. Lambda = {lam}.')
        print(f'K_E = {float(ke):.12g}, K_D = {float(kd):.12g}. R_V = {float(rv):.12g}, R_C = {float(rc):.12g}.')
        tope = '0.001243' if sin_cuatro else '0.312'
        print(f'Holgura mínima en las filas con comparación de márgenes = {float(margen):.6%}.')
        print(f'Retención local en p=1e-6 < {tope} (mayorante aproximado {float(reten):.12g}).')
