"""Primera fusión en H5-A. Ejecutar con Python 3.10+ desde el paquete."""
from fractions import Fraction as F
from math import ceil, comb, factorial, floor

import verificar_H5A_enlaces as anterior
from verificar_H5A_consumo import ALFA, Q, XI, carga_grupo
from verificar_H5A_interacciones import cotas_locales, escalar, exigir, exp_arriba, geometria, perfil


def elegir(n, k):
    return comb(n, k) if 0 <= k <= n else 0


def candidatos_por_check(r):
    total = 0
    for x in range(19):
        for j in range(18):
            m = x+j
            a = 17*x+18*j-2*x*j
            if m and 2*a >= 17*m and a <= 18*r:
                total += elegir(17,x-1)*elegir(16,j) + elegir(17,x)*elegir(16,j-1)
    return 306*total


N3, N4, N5 = (candidatos_por_check(r) for r in (3,4,5))
NMAX = 306*2**34


def cubiertas(y):
    exigir(0 <= y < 1, 'actividad de lectores')
    return y**2*(N3+y*(N4+y*(N5+NMAX*y/(1-y))))


def derivada(y):
    exigir(0 <= y < 1, 'derivada de la serie de cubiertas')
    return y*(2*N3+y*(3*N4+y*(4*N5+NMAX*y*(5-4*y)/(1-y)**2)))


def odds(p):
    return p/(1-p)


def inferior_exp(y, orden):
    return sum(y**i/factorial(i) for i in range(orden+1))


def esquina(cota_exp=exp_arriba):
    # La actividad temporal t y las filas de acción S,P,C se heredan íntegras.
    _,lam,ke,kd,rv,rc,_ = anterior.verificar(False,cota_exp)
    _,_,S,P,_,_ = anterior.constantes(False)
    base,v2,c2 = geometria()
    orden = (0,1,3,0,1,2)
    M = [[base[i][j] for j in orden] for i in orden]
    mv = max(sum(row[:2]) for row in base[:2])
    mc = max(row[3] for row in base[:2])
    cv,cc = sum(base[3][:2]),base[3][3]
    anchos,lectores = (17,18,1,17,18,306),(18,17,1,18,17,306)
    Z = [escalar(M[i],S) + sum(anchos[i]*b*p for b,p in zip(lectores[3:],P))/(1-lam) for i in range(3)]
    zv,zc = max(Z[:2]),Z[2]
    _,pv,pc,cp = cotas_locales(False)
    t,s,x = F('0.0067'),F('4.37'),F('7e-9')
    rho,uno = F('1.294e-11'),F('1.106e-8')
    uv,uc = F('2.01676e-9'),F('3.20755e-13')
    def superior(z):
        precision = 10**65
        return F(ceil(precision*cota_exp(z)),precision)

    exigir(carga_grupo(1)==9 and uno**50>=t**183, 'grupo con un dato')
    for e in range(2,17):
        holgura = ALFA*e-carga_grupo(e)
        exigir(holgura>=0 and t**floor(1000*holgura) <= (rho*s**e)**1000, f'descuento de {e} datos')
    exigir(rho*s**17>=1, 'todos los grados desde 17')

    av,ac = s*x*superior(zv+mv*uv+mc*uc),XI*superior(zc+cv*uv)
    v = av*superior(mc*ac)
    wv,wc = v*superior(mv*v),ac*superior(cv*v)
    y = 35*wv+wc
    kv = wv*(pv*wv+pc*wc+18*cubiertas(y))
    kc = wc*(cp*wv+35*wv*derivada(y))
    dv = kv+v*(mv*kv+mc*kc)
    dc = kc+ac*cv*dv
    d0 = XI*superior(zc)
    v0 = x*uno*superior(zv+mc*d0)
    b0 = pc*d0+18*cubiertas(d0)
    sv = v0*b0+rho*uv
    sc = d0*v0*(cp+cv*b0+35*derivada(d0))+rho*uc
    margenes = (uv/dv-1,uc/dc-1,min(S[:2])/sv-1,S[2]/sc-1)
    exigir(min(margenes)>0, 'componentes y sus dos entradas físicas')

    p0,p1 = F('7.5e-37'),F('2e-36')
    lv,lc = F('5e-36'),F('5.81e-11')
    nucleo = max(S[0]+S[3]+17*S[5],S[1]+S[4]+18*S[5])
    nc = S[2]+35*nucleo
    exigir(lv > odds(p0)*superior(F('1.01')+mv*(lv+nucleo)+mc*(lc+nc)), 'datos exteriores')
    exigir((F('2.79')*odds(p0))**50 < x**50*t**633, 'odds con presupuesto unitario')
    kappa = F(1,80)
    exigir(max(ke,kd)<kappa and odds(p1)<odds(p0)*inferior_exp(1-kappa,7), 'mismo criterio con presupuesto kappa F')
    return p0,p1,ke,kd,rv,rc,margenes


def meta(cota_exp=exp_arriba):
    z,zq = odds(F('1e-6')),odds(Q)
    _,pv,pc,cp = cotas_locales(False)
    local = pv*F('1e-6')+pc*Q+18*cubiertas(F(35,10**6)+Q)
    exigir(local<F('0.035787'), 'dato señalado en la meta')
    B = 83810
    H = F(578,32)+F(B,4096)/(1-F(B,2**18))
    filas = []
    for codigo,tv,tc,dist,peso,peaje in (
        ('enlaces y cubiertas',F('1.5e-5'),F('1.25e-10'),H,F(1,32),2),
        ('contactos y cubiertas',F('6e-6'),F('8e-11'),F(0),F(1),1),
    ):
        y = 35*tv+tc
        fv = F('1.06')+(pv+630*dist)*tv+(pc+18*dist)*tc+18*peso*cubiertas(y)
        fc = F('1.06')+(cp+35*dist)*tv+dist*tc+peso*cubiertas(y)
        vv = peaje*F(51,50)*z*cota_exp(fv)
        vc = peaje*zq*cota_exp(fc)
        exigir(vv<tv and vc<tc,codigo)
        filas.append((codigo,vv,vc))
    # t_i = exp(1) z_i. Para el mayorante de inversos se usa W_i=t_i exp(3t_i).
    # La sustitución inversa z=b/(1-eta b) incluye ambas coordenadas formales.
    e_sup = cota_exp(F(1))
    perdida = (1+e_sup)*z
    exigir(perdida<F(1,2), 'conversión de actividades normalizadas')
    tmax = e_sup*z/(1-perdida)
    fac = cota_exp(3*tmax)
    exigir(tmax<F('0.000003') and 1+2*perdida+3*tmax < F('1.06'), 'inclinación del logaritmo')
    exigir(cota_exp(F(1,4))<F(4,3), 'inversos de bloques internos de actividad total pequeña')
    exigir(tmax*fac<1 and 2*(tmax*fac)**2<F(1,2), 'serie geométrica por nodo interno')
    exigir(2+4*tmax*fac**2<3, 'producto de inversos en una jerarquía arbitraria')
    return local,filas


if __name__=='__main__':
    perfil()
    anterior.rutas()
    exigir((N3,N4,N5)==(343944,3683016,146395296), 'candidatos por check')
    p0,p1,ke,kd,rv,rc,margenes = esquina()
    print(f'PASS general con q <= 2e-11. p unitario = {float(p0):.3g}. p con F/80 = {float(p1):.3g}.')
    print(f'K_E <= {float(ke):.12g}, K_D <= {float(kd):.12g}, R_V <= {float(rv):.12g}, R_C <= {float(rc):.12g}.')
    print('Holguras relativas de las cuatro filas de grupos:', ', '.join(f'{float(m):.6%}' for m in margenes))
    prob,filas = meta()
    print(f'PASS en la meta. Probabilidad condicional de señalamiento <= {float(prob):.12g}.')
    for codigo,vv,vc in filas:
        print(f'PASS {codigo}: {float(vv):.12g}, {float(vc):.12g}.')
    print('PASS constantes del logaritmo para primeras fusiones anidadas, con repeticiones a cualquier orden.')
