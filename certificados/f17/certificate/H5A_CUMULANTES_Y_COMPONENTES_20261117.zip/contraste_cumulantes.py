"""Controles independientes del perfil cronológico y de la inversión en componentes."""
from fractions import Fraction as F
from functools import cache
from math import ceil, factorial, lcm

import verificar_H5A_cumulantes as prueba
from contraste_fusiones import otra_exp


def perfil_por_prefijos(v, c):
    pesos = prueba.DUAL_ACCIONES
    escala = lcm(*(u.denominator for u in pesos.values()))
    estados = {}
    for k in range((18 if c else 17)+1):
        vivos = v*min(17,k)+c*k
        estados[k,vivos] = vivos*int(escala*pesos[None])
    for nivel in sorted((u for u in pesos if u is not None), reverse=True):
        alto = ceil(18*(1+nivel)/2)-1
        bajo = ceil(17*(1+nivel)/2)-1
        nuevos = {}
        for (anterior,saldo),valor in estados.items():
            for k in range(1+min(anterior, alto if c else bajo)):
                retiro = max((17*anterior+17)//18, bajo+1) if k<anterior else 0
                vivos = min(v*min(bajo,k)+c*min(alto,k),max(0,saldo-retiro))
                clave = (k,vivos)
                coste = valor+int(escala*pesos[nivel])*vivos
                nuevos[clave] = max(nuevos.get(clave,0),coste)
        estados = nuevos
    return F(max(estados.values()), escala)


def subconjuntos(s):
    u = s
    while u:
        yield u
        u = (u-1)&s


def particiones(piezas):
    if not piezas:
        yield ()
        return
    primero,*resto = piezas
    for particion in particiones(resto):
        yield (primero,)+particion
        for j in range(len(particion)):
            yield particion[:j]+(primero|particion[j],)+particion[j+1:]


def producto(valores):
    salida = 1
    for x in valores:
        salida *= x
    return salida


def identidades():
    # Los componentes se inducen de nuevo en cada subconjunto. Los ceros
    # y signos de la marca controlan también los casos de máscara y filtro.
    vertices = (1,2,4,8,16,32)
    completo = sum(vertices)
    for aristas in ((), ((1,2),(2,4),(1,4),(4,8),(16,32)),
                    tuple((a,b) for a in vertices for b in vertices if a<b)):
        vecinos = {v: v for v in vertices}
        for a,b in aristas:
            vecinos[a] |= b
            vecinos[b] |= a
        def alrededor(s):
            res = 0
            for v in vertices:
                if s&v:
                    res |= vecinos[v]
            return res
        def componentes(s):
            salida = []
            while s:
                v = s&-s
                while (alrededor(v)&s) != v:
                    v = alrededor(v)&s
                salida.append(v)
                s ^= v
            return salida
        for ejemplo in (0,1,2):
            def marca(s):
                if not s:
                    return 1
                return ((73*s ^ (s*(s+ejemplo+5)) ^ (s>>2) ^ ejemplo)%3)-1
            @cache
            def k(s):
                a = s&-s
                return marca(s)-sum(k(u)*marca(s^u) for u in subconjuntos(s) if u!=s and u&a)
            @cache
            def d(s):
                return sum((-1)**(len(pi)-1)*factorial(len(pi)-1)*producto(marca(b) for b in pi)
                           for pi in particiones(componentes(s)))
            @cache
            def coef_gas(s):
                if not s:
                    return 1
                a = s&-s
                return sum(d(u)*coef_gas(s^u) for u in subconjuntos(s)
                           if u&a and alrededor(u)&(s^u)==0)
            for s in subconjuntos(completo):
                assert coef_gas(s)==marca(s)
                total = 0
                for pi in particiones([v for v in vertices if v&s]):
                    alcanzado = s&-s
                    while True:
                        extendido = alrededor(alcanzado)&s
                        for b in pi:
                            if b&alcanzado:
                                extendido |= b
                        if extendido==alcanzado:
                            break
                        alcanzado = extendido
                    if alcanzado==s:
                        total += producto(k(b) for b in pi)
                assert d(s)==total


if __name__=='__main__':
    for e in range(1,17):
        for v in range(e+1):
            assert perfil_por_prefijos(v,e-v)==prueba.perfil_grupo(v,e-v)
    print('PASS perfiles por recorrido hacia adelante para las 152 composiciones de 1 a 16 datos.')
    identidades()
    print('PASS identidad de gas y cumulante de productos para todas las restricciones de nueve ejemplos.')
    prueba.general(otra_exp)
    prueba.meta(otra_exp)
    print('PASS todas las filas con la segunda cota exponencial racional.')
