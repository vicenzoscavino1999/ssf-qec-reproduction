"""H5-A, cumulantes de fuentes. Python 3.10+, biblioteca estándar."""
from fractions import Fraction as F
from functools import cache
from math import ceil, comb, floor, lcm

from verificar_H5A_enlaces import rutas
from verificar_H5A_fusiones import N3, N4, N5, cubiertas, derivada
from verificar_H5A_interacciones import (
    DUAL_ACCIONES, cotas_locales, escalar, exigir, exp_arriba, geometria, perfil,
)


NIVELES = tuple(sorted((u for u in DUAL_ACCIONES if u is not None), reverse=True))
ESCALA = lcm(*(w.denominator for w in DUAL_ACCIONES.values()))
FILAS = tuple((ceil(17*(1+u)/2)-1, ceil(18*(1+u)/2)-1,
               ceil(17*(1+u)/2), int(ESCALA*DUAL_ACCIONES[u])) for u in NIVELES)
P_GENERAL, Q = F('3.6e-36'), F('2e-11')
P_META = F('1e-6')


def actividad(p):
    return p/(1-2*p)


def exponencial(cota):
    precision = 10**58
    def arriba(z):
        return F(ceil(precision*cota(z)), precision)
    return arriba


@cache
def perfil_grupo(v, c):
    """Máximo de la combinación dual, en un grupo con v datos VV y c CC."""
    @cache
    def resto(j, k, saldo):
        if j == len(FILAS):
            return 0
        bv, bc, requisito, peso = FILAS[j]
        tope = min(k, bc if c else bv)
        mejor = 0
        for nuevo in range(tope+1):
            consumo = max(requisito, ceil(F(17*k, 18))) if nuevo < k else 0
            cuenta = min(v*min(nuevo, bv)+c*min(nuevo, bc), max(0, saldo-consumo))
            mejor = max(mejor, peso*cuenta + resto(j+1, nuevo, cuenta))
        return mejor
    peso_inicial = int(ESCALA*DUAL_ACCIONES[None])
    valores = []
    for k in range(19 if c else 18):
        saldo = v*min(17, k)+c*k
        valores.append(peso_inicial*saldo + resto(0, k, saldo))
    return F(max(valores), ESCALA)


def cronologia(t, s, rho):
    def lineal(n):
        return n*DUAL_ACCIONES[None] + sum(
            (ceil(n*(1+u)/2)-1)*DUAL_ACCIONES[u] for u in NIVELES)
    exigir(lineal(17) == F(10039577,816816) < F('12.30'), 'tipo VV, todo grado')
    exigir(lineal(18) == F(3446943,272272) < F('12.66'), 'tipo CC, todo grado')
    exigir(perfil_grupo(1,0) == perfil_grupo(0,1) == 9, 'un solo dato')
    for e in range(2,17):
        delta = min(F('12.66')*e - F('.36')*v - perfil_grupo(v,e-v) for v in range(e+1))
        exigir(delta >= 0 and t**floor(1000*delta) <= (rho*s**e)**1000, f'descuento, {e} datos')
    exigir(rho*s**17 >= 1, 'cola de grupos de todos los tamaños')


def general(cota=exp_arriba):
    exp = exponencial(cota)
    t, x, s, rho, xi = F('.00665'), F('1.36e-8'), F(4), F(1,4**17), F('2.07e-11')
    cronologia(t, s, rho)
    precio_v, uno = F('.16452'), F('1.0754e-8')
    exigir(precio_v**25 >= t**9 and uno**50 >= t**183, 'precios de tipo y singleton')
    S = list(map(F, ('3.036918191e-20','1.677545077e-19','8.353195291e-24',
                     '2.014322932e-18','1.91953247e-18','1.921077002e-17')))
    P = list(map(F, ('5.686882931e-12','5.395221995e-12','5.773761201e-11')))
    C = list(map(F, ('2.149604788e-23','2.168936913e-23','3.694908587e-21')))
    U = list(map(F, ('5.175957097e-10','2.859125398e-09','1.007609196e-13')))
    base, v2, c2 = geometria()
    orden = (0,1,3,0,1,2)
    M = [[base[i][j] for j in orden] for i in orden]
    N = [fila[:3] for fila in M[:3]]
    N[2][2] = 0
    vv = max(sum(fila[:2]) for fila in base[:2])
    vc = max(fila[3] for fila in base[:2])
    cv, cc = sum(base[3][:2]), base[3][3]
    _, pv, pc, cp = cotas_locales(False)
    exigir(17*17+2*17*17*18 <= 10700 and 18*16+2*18*16*17 <= 10100, 'dos datos del mismo tipo')
    exigir(324+20*18+324*18+11016 <= 17600, 'dos datos de distinto tipo')
    lam = t*(F(c2,4)+F(v2-1,7)+F((v2-1)*(c2-1),17)*t)
    exigir(lam<1 and t/4<F(1,17), 'serie de tramos')
    ancho = (17,18,1,17,18,306)
    lectores = (18,17,1,18,17,306)
    J = [[a*b/(1-lam) for b in lectores] for a in ancho]
    L = [escalar(fila[3:],P) for fila in J]
    W = [escalar(fila,S) for fila in M]
    Z = [l+w for l,w in zip(L,W)]
    a = [peso*exp(Z[i]+escalar(N[i],U)) for i,peso in enumerate((s*x*precio_v,s*x,xi))]
    v = [a[i]*exp(N[i][2]*a[2]) for i in range(2)]
    w = [valor*exp(escalar(N[i][:2],v)) for i,valor in enumerate(v+[a[2]])]
    datos = 18*w[0]+17*w[1]
    y = datos+w[2]
    contactos = [min(pv*max(w[:2]), escalar(fila,w[:2]))
                 for fila in ((10700,17600),(17600,10100))]
    K = [w[i]*(contactos[i]+pc*w[2]+18*cubiertas(y)) for i in range(2)]
    K.append(w[2]*(cp*max(w[:2])+datos*derivada(y)))
    D = [K[i]+v[i]*escalar(N[i],K) for i in range(2)]
    D.append(K[2]+a[2]*escalar(N[2][:2],D))
    d0 = xi*exp(Z[2])
    v0 = [x*uno*exp(Z[i]+N[i][2]*d0) for i in range(2)]
    b0 = pc*d0+18*cubiertas(d0)
    solo = [u*b0 for u in v0]
    solo.append(d0*(cp*max(v0)+escalar(N[2][:2],v0)*b0+(18*v0[0]+17*v0[1])*derivada(d0)))
    margenes = {}
    def comparar(izq, der, nombre):
        exigir(izq > der > 0, nombre)
        margenes[nombre] = izq/der-1
    for i in range(3):
        comparar(U[i],D[i],f'bloque {i}')
        comparar(S[i],solo[i]+rho*U[i],f'origen {i}')
    for j in range(3):
        i = j+3
        b = (F(1,9),F(1,10),F(1,17))[j]
        bp = (F(1,7),F(1,8),F(1,15))[j]
        extra = F(1,4)-b if j==2 else F(0)
        G, H = exp(Z[i]), exp(W[i])
        causas = escalar(J[i],S[:3]+C)
        sat = ancho[i]*xi
        exigir(sat<F(1,2), 'medidas adscritas')
        m, r = bp*(exp(sat)-1)*G, t*sat**3*G
        comparar(P[j], t*(b*(G-1-L[i])+m+extra*L[i]*(H-1)), f'causa {i}')
        comparar(C[j], r+t*causas*(b*(G-1)+m+extra*(H-1)), f'hijo {i}')
        comparar(S[i], r+t*causas*(b*G+m+extra*L[i]*H), f'puente {i}')
    lv, lc = F('5e-36'), F('2.055e-11')
    nucleo = max(S[0]+S[3]+17*S[5], S[1]+S[4]+18*S[5])
    nc = S[2]+35*nucleo
    yp,yq = actividad(P_GENERAL),actividad(Q)
    inclinacion = F('.0201')
    comparar(lv, yp*exp(inclinacion+vv*(lv+nucleo)+vc*(lc+nc)), 'datos exteriores')
    comparar(lc, yq*exp(inclinacion+cv*(lv+nucleo)+cc*(lc+nc)), 'medidas exteriores')
    comparar(xi, yq*exp(inclinacion+cv*lv+cc*lc), 'conversión de medidas')
    comparar(F('1.03'), exp(inclinacion+135*(vv*lv+vc*lc)), 'inclinación de datos')
    exigir((F('1.03')*yp)**50 < x**50*t**633, 'conversión de datos')
    rv, rc = nucleo+18*lv, nc+lc
    ke, kd = 135*(vv*rv+vc*rc), cv*rv+cc*rc
    exigir(0<max(ke,kd)<F('.01') and 0<max(rv,rc)<F('.0001'), 'los dos presupuestos KP')
    return lam, ke, kd, rv, rc, min(margenes.values())


def meta(cota=exp_arriba):
    exp = exponencial(cota)
    V,D = actividad(P_META),actividad(Q)
    tv,tc = F('1.35e-5'),F('1.8e-10')
    bola,razon = 83810,F(55,54)
    exigir(razon**716>480001 and 51+36*716<30000,'coste radial para cualquier tamaño')
    H = (F(578,32)+F(bola,4096)/(1-F(bola,2**18)))/8
    y = 35*tv+tc
    gv = 2*V*exp(F('1.41')+(28200+630*H)*tv+(40+18*H)*tc+18*cubiertas(y)/32)
    gc = 2*D*exp(F('1.41')+(800+35*H)*tv+(bola+H)*tc+cubiertas(y)/32)
    pagar = (28201*tv+40*tc, 800*tv+bola*tc)
    exigir(gv<tv and gc<tc and max(pagar)<F('.4'), 'componentes de contacto, todo grado')
    exigir((N3,N4,N5)==(343944,3683016,146395296), 'cubiertas')
    exigir(F(20,33)<F(15,17) and (18*18)//13==24 and 24*18==432,'un dato, dos medidas')
    exigir(F(22,33)<F(16,17) and 35-ceil(F(8*33,9))<=5, 'dos líneas diferentes')
    v,d = V*exp(F('1.01')),D*exp(F('1.01'))
    av3 = comb(28200,2)+28200**2+18*N3*35**2
    av2m = 40*800+18*N3*70+28200*(80+bola*(36+306*36))
    am2v = (comb(800,2)+N3*35**2+800*28200
            +35*bola**2*28200+35*307**4*10700)
    l2v,l2c = 2*v*(28200*v+40*d),2*d*800*v
    l3v = 6*(av3*v**3+av2m*v**2*d+comb(432,2)*v*d**2)
    l3c = 6*(am2v*v**2*d+840*432*v*d**2)
    totv,totc = tv+l2v+l3v,tc+l2c+l3c
    exigir(max(totv,totc)<F('3e-5'), 'pares, tríos y subserie de orden arbitrario')
    # Esto verifica el margen disponible, no la hipótesis sobre el residuo.
    ev,ec = F('5e-7'),F('1e-6')
    exigir(28201*(tv+ev)+40*(tc+ec)<F('.4') and
           800*(tv+ev)+bola*(tc+ec)<F('.4'), 'condición suficiente sobre bloques pendientes')
    return H,gv,gc,l2v,l2c,l3v,l3c,totv,totc


if __name__=='__main__':
    _,firmas,_ = perfil()
    direcciones = rutas()
    lam,ke,kd,rv,rc,margen = general()
    print(f'PASS {firmas} firmas y {direcciones} orientaciones débiles potenciales.')
    print(f'PASS p <= {float(P_GENERAL):.3g}, q <= {float(Q):.3g}, para todo tamaño. Lambda = {lam}.')
    print(f'K_E = {float(ke):.12g}, K_D = {float(kd):.12g}, R_V = {float(rv):.12g}, R_C = {float(rc):.12g}.')
    print(f'Mínima holgura relativa de las filas de árbol y exterior = {float(margen):.6%}.')
    h,gv,gc,v2,c2,v3,c3,vt,ct = meta()
    print(f'PASS p = 1e-6, q = 2e-11. H = {float(h):.10g}. Filas del árbol de componentes: {float(gv):.10g}, {float(gc):.10g}.')
    print(f'Cargas de pares: {float(v2):.10g}, {float(c2):.10g}. De tríos: {float(v3):.10g}, {float(c3):.10g}.')
    print(f'PASS cargas de la subserie combinada: {float(vt):.10g}, {float(ct):.10g}. Sigue abierto el resto de orden >= 4 en la meta.')
