"""Certificado racional de H5A_enlaces_entre_grupos.txt, Python 3.10 o posterior.

Ejecutar con python verificar_H5A_enlaces.py en la carpeta del paquete.
"""
from fractions import Fraction as F
from functools import cache
from math import ceil, factorial, floor
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from verificar_H5A_consumo import ALFA, Q, XI, carga_grupo
from verificar_H5A_interacciones import (
    DUAL_ACCIONES, coeficiente, cotas_locales, escalar, exigir, exp_arriba,
    geometria, limite_dual, perfil,
)


@cache
def coste(a, d):
    return coeficiente(DUAL_ACCIONES, a, d)


def rutas():
    revisados = 0
    for x in range(19):
        for j in range(18):
            a = 17*x+18*j-2*x*j
            if x+j < 2 or 2*a < 17*(x+j):
                continue
            for d in range(a%2,a,2):
                if 100*d < a or coste(a,d) >= 2:
                    continue
                h = (a+d)//2
                fk, ck = min(17-j,17*h//a), min(18-x,18*h//a)
                if x*fk+j*ck < h:
                    continue
                for horizontal, cantidad, of, oc in (
                    (True,x*(17-j),17-j,x), (False,(18-x)*j,j,18-x),
                ):
                    if not cantidad:
                        continue
                    bf = max(0,ceil(F((2*of-17)*h,a)))
                    bc = max(0,ceil(F((2*oc-18)*h,a)))
                    if horizontal:
                        bf = max(bf,h-(x-1)*fk-j*ck)
                    else:
                        bc = max(bc,h-x*fk-(j-1)*ck)
                    if bf >= of or bc >= oc:  # el check transmitido estaba apagado
                        continue
                    exigir(bf >= 4 or bc >= 7, f'ejes de {x},{j},{d},{horizontal}')
                    revisados += 1
    exigir(revisados>0 and limite_dual(DUAL_ACCIONES)<=ALFA, 'perfil de rutas')
    return revisados


def constantes(sin_cuatro):
    if sin_cuatro:
        p, x = F('1.2e-36'), F('1.12e-8')
        S = ('2.52298e-20','2.52298e-20','4.15491e-24','8.25882e-19','7.87017e-19','7.87533e-18')
        P = ('3.13962e-12','2.96205e-12','3.22732e-11')
        C = ('7.18000e-24','7.24456e-24','1.23293e-21')
        U = ('1.20163e-9','1.86310e-13')
    else:
        p, x = F('6.6e-37'), F('6.13e-9')
        S = ('2.93731e-20','2.93731e-20','8.09496e-24','1.12851e-18','1.07540e-18','1.07635e-17')
        P = ('3.96868e-12','3.75074e-12','4.34717e-11')
        C = ('1.32062e-23','1.33250e-23','2.26780e-21')
        U = ('1.39897e-9','2.40681e-13')
    return p,x,*(list(map(F,seq)) for seq in (S,P,C,U))


def verificar(sin_cuatro, cota_exp=exp_arriba):
    def superior(z):
        # Las cotas se anidan. Acotar hacia arriba limita el tamaño de los
        # denominadores conservando el sentido de todas las desigualdades.
        precision=10**65
        return F(ceil(precision*cota_exp(z)),precision)
    p,x,S,P,C,U = constantes(sin_cuatro)
    t,s,rho,uno = map(F,('0.0067','4.25','2.08e-11','1.106e-8'))
    exigir(carga_grupo(1)==9 and uno**50>=t**183, 'precio de un solo dato')
    for e in range(2,17):
        delta = ALFA*e-carga_grupo(e)
        exigir(delta>=0 and t**floor(1000*delta)<=(rho*s**e)**1000, f'inclinación, e={e}')
    exigir(rho*s**17>=1, 'todos los grupos de al menos 17 datos')
    base, v2, c2 = geometria()
    indice = (0,1,3,0,1,2)
    M = [[base[i][j] for j in indice] for i in indice]
    vv = max(sum(row[:2]) for row in base[:2])
    vc = max(row[3] for row in base[:2])
    cv, cc = sum(base[3][:2]), base[3][3]
    k, pv, pc, cp = cotas_locales(sin_cuatro)
    ng, nr = 18*306, 18*v2+17*c2
    lam = t*(F(c2,4)+F(v2-1,7)+F((v2-1)*(c2-1),17)*t)
    exigir(lam<1 and t/4<F(1,17), 'serie de cadenas')
    f = (17,18,1,17,18,306)
    J = [[a*b/(1-lam) for b in (18,17,1,18,17,306)] for a in f]
    L = [escalar(row[3:],P) for row in J]
    W = [escalar(row,S) for row in M]
    Z = [l+w for l,w in zip(L,W)]
    zv,zc = max(Z[:2]),Z[2]
    uv,uc = U
    av = s*x*superior(zv+vv*uv+vc*uc)
    ac = XI*superior(zc+cv*uv)
    v = av*superior(vc*ac)
    wv,wc = v*superior(vv*v), ac*superior(cv*v)
    h = nr*wv+306*wc
    kv = wv*(pv*wv+pc*wc+ng*h**(k-1)/factorial(k-1))
    kc = wc*(cp*wv+306*nr*wv*h**(k-2)/factorial(k-2))
    desde_dato = kv+v*(vv*kv+vc*kc)
    desde_medida = kc+ac*cv*desde_dato
    d0 = XI*superior(zc)
    v0 = x*uno*superior(zv+vc*d0)
    testigo = pc*d0+ng*(306*d0)**(k-1)/factorial(k-1)
    solov = v0*testigo
    soloc = d0*v0*(cp+cv*testigo+306*nr*(306*d0)**(k-2)/factorial(k-2))
    margenes = []
    def comparar(izq, der, nombre):
        exigir(izq>der>0,nombre)
        margenes.append(izq/der-1)
    comparar(uv,desde_dato,'bloques, entrada por dato')
    comparar(uc,desde_medida,'bloques, entrada por medida')
    comparar(min(S[:2]),solov+rho*uv,'origen que entra por dato')
    comparar(S[2],soloc+rho*uc,'origen que entra por medida')

    for j in range(3):
        i=j+3
        b=(F(1,9),F(1,10),F(1,17))[j]
        bp=(F(1,7),F(1,8),F(1,15))[j]
        extra=F(1,4)-b if j==2 else F(0)
        G,H=superior(Z[i]),superior(W[i])
        causas=escalar(J[i],S[:3]+C)
        sat=f[i]*XI
        exigir(sat<F(1,2),'medidas adscritas')
        m=bp*(superior(sat)-1)*G
        r=t*sat**3*G
        comparar(P[j],t*(b*(G-1-L[i])+m+extra*L[i]*(H-1)),f'causa {i}')
        comparar(C[j],r+t*causas*(b*(G-1)+m+extra*(H-1)),f'hijo {i}')
        comparar(S[i],r+t*causas*(b*G+m+extra*L[i]*H),f'puente {i}')

    lv,lc=F('5e-36'),F('5.81e-11')
    nucleo=max(S[0]+S[3]+17*S[5],S[1]+S[4]+18*S[5])
    nc=S[2]+35*nucleo
    zp,zq=p/(1-p),Q/(1-Q)
    a=F('1.01')
    comparar(lv,zp*superior(a+vv*(lv+nucleo)+vc*(lc+nc)),'datos exteriores')
    comparar(lc,zq*superior(a+cv*(lv+nucleo)+cc*(lc+nc)),'medidas exteriores')
    rv,rc=nucleo+18*lv,nc+lc
    ke,kd=135*(vv*rv+vc*rc),cv*rv+cc*rc
    exigir(0<ke<1 and 0<kd<1 and 0<rv<1 and 0<rc<1,'carga física y anclas')
    comparar(XI,zq*superior(a+cv*lv+cc*lc),'conversión de q')
    comparar(F('2.79'),superior(a+135*(vv*lv+vc*lc)),'inclinación física de p')
    exigir((F('2.79')*zp)**50<x**50*t**633,'conversión de p')
    return p,lam,ke,kd,rv,rc,min(margenes)


def puentes(superior=exp_arriba):
    _,v2,c2=geometria()
    B=v2*c2
    beta,r=F(1,100),F(55,54)
    gamma=1-(r-1)*(1-beta)/(2*beta)
    exigir(gamma==F(1,12) and 36*(r-1)/gamma==8,'presupuesto de las capas')
    exigir(r**664>=1+8*24000 and 48+36*664<=24000,'densidad de grupos')
    t_v,t_c = F('1.5e-5'),F('1.25e-10')
    z = F(1,999999)
    ampliacion=F(51,50)
    _,pv,pc,cp=cotas_locales(False)
    ejes=v2+c2-1
    exigir(B<2**18,'suma de enlaces a distancia arbitraria')
    por_check=F(ejes,32)+F(B,4096)/(1-F(B,2**18))
    fv=F('1.06')+(pv+18*35*por_check)*t_v+(pc+18*por_check)*t_c
    fc=F('1.06')+(cp+35*por_check)*t_v+por_check*t_c
    rhs_v=2*ampliacion*z*superior(fv)
    rhs_c=2*Q/(1-Q)*superior(fc)
    exigir(rhs_v<t_v and rhs_c<t_c,'árboles con enlaces en p=1e-6')
    # |A(S)| <= 2^f. Un inferior de exp(1.06-0.35) paga ese
    # factor y la sustitución de cada odds por la actividad normalizada.
    z_mayor=max(z,Q/(1-Q))
    inferior=sum(F(71,100)**j/factorial(j) for j in range(5))
    exigir(F(2)/(1-z_mayor)<inferior,'cola de coeficientes normalizados en el árbol de fuentes')
    return rhs_v,rhs_c


if __name__=='__main__':
    _,firmas,_=perfil()
    direcciones=rutas()
    print(f'Perfil verificado en {firmas} firmas locales y {direcciones} casos de orientación con coeficiente menor que 2.')
    for sin_cuatro in (False,True):
        p,lam,ke,kd,rv,rc,margen=verificar(sin_cuatro)
        clase='sin ciclos de cuatro' if sin_cuatro else 'binaria (17,18)-regular general'
        print(f'PASS {clase}. p <= {float(p):.2g}, q <= 2e-11. Lambda = {lam}.')
        print(f'K_E = {float(ke):.12g}, K_D = {float(kd):.12g}, R_V = {float(rv):.12g}, R_C = {float(rc):.12g}.')
        print(f'Margen mínimo en las filas comparadas = {float(margen):.5%}.')
    rv,rc=puentes()
    print(f'PASS subserie a p=1e-6, q=2e-11. Filas <= {float(rv):.10g} y {float(rc):.10g}.')
    print('Incluye todos los tamaños con g-1 <= (|E|+|D|)/24000 y los árboles de coste <= |E|+|D|.')
    print('PASS cola normalizada por fuente exp(-0.35(M+1)) sobre soportes con ese coste de árbol.')
